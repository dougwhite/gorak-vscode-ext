export type StyleObject = Record<string, unknown>;
export interface StylesLayer {
    origin: string;
    defaults: StyleObject;
}
/** Named stylesheet resolution; these values never cascade into existing fields. */
export declare function mergeStyles(parent: StyleObject, delta: StyleObject, depth?: number): StyleObject;
export declare function numberedSlots(v: unknown, prefix: string): string[];
export declare function resolveStyles(layers: readonly StylesLayer[]): StyleObject;
export interface StyleEntry {
    group: string;
    slot: string;
    ordinal: number;
    kind: string;
    sample: StyleObject;
}
export declare function styleEntries(layers: readonly StylesLayer[]): StyleEntry[];
/** Adapt native sample objects to creation data, preserving typed rows/attributes. */
export declare function sampleProperties(value: unknown, depth?: number): unknown;
