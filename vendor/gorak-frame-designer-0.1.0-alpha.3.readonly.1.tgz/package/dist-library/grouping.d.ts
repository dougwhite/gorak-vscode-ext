import { type EditIntent, type WmlDocument } from "./wml.js";
export interface GroupMember {
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
    properties?: Readonly<Record<string, string>>;
}
export type GroupKind = "flexibleform" | "subform" | "stackfield";
/** Move whole child source between stack slots; comments between slots remain untouched. */
export declare function reorderStack(doc: WmlDocument, parentId: string, members: readonly GroupMember[], orientation?: number): EditIntent;
/** Wrap original child source, changing only its coordinates. Unknown child data remains opaque. */
export declare function groupFields(doc: WmlDocument, members: readonly GroupMember[], kind: GroupKind, style?: number, orientation?: number): EditIntent;
/** An ungroup operation refuses to discard parent scripts or structured properties. */
export declare function ungroupField(doc: WmlDocument, id: string, children: readonly GroupMember[], parentX: number, parentY: number): EditIntent;
