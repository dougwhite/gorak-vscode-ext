/** Native empty_frame scaffolding, verified through isolated import/re-export. */
export declare function newFrameSource(width?: number, height?: number): {
    text: string;
    metadata: string;
};
/** Observed template defaults; other templates remain unresolved unless the host supplies them. */
export declare const emptyFrameDefaults: Readonly<Record<string, string>>;
