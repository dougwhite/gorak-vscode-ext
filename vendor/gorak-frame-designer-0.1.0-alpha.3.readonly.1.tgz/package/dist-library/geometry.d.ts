/** Calibrated OpenROAD placement grid: integer CSS reference pixels at 96 dpi. */
export declare const WML_TO_CSS: number;
export declare const sourcePosition: (cssPixels: number) => number;
/** Segment endpoints are parent coordinates, so they move/scale with their bounds. */
export declare function segmentGeometry(properties: Readonly<Record<string, string>>, values: Record<string, number>): Record<string, number>;
