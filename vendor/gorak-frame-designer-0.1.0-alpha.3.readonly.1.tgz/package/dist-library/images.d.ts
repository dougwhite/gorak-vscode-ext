import type { WmlNode } from "./wml.js";
import { type FieldBitmap } from "./bitmap.js";
/** Hosts resolve source references to bounded pixels; source filenames are never URLs. */
export type FrameImages = Readonly<Record<string, FieldBitmap>>;
export declare function imageKey(node: WmlNode): string;
export declare function nodeBitmap(node: WmlNode | undefined, images?: FrameImages): FieldBitmap | undefined;
/** A native monochrome image uses black foreground and clear background. */
export declare function applyImageTransparency(rgba: Uint8ClampedArray, flags?: string, transparent?: Uint8Array): void;
