import type { FrameDocument } from "./designer.js";
import { type DefaultsLayer, type WmlDocument } from "./wml.js";
import type { FrameMetadata } from "./metadata.js";
import { type FrameImages } from "./images.js";
export { WML_TO_CSS } from "./geometry.js";
export declare function frameFromWml(source: WmlDocument, layers: readonly DefaultsLayer[], metadata?: FrameMetadata, images?: FrameImages): FrameDocument;
