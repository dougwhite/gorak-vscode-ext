//#region src/native-defaults.ts
var e = {
	displaypolicy: "1",
	bmpdisplaybehavior: "0",
	declared: "1",
	isnullable: "1",
	ispropoptinherited: "0",
	isreverse: "0",
	requirerealfield: "0",
	tabseqnum: "0",
	anchorpoint: "0",
	outlinestyle: "-1",
	outlinewidth: "-1"
};
function t(t) {
	return t === "columnfield" ? {
		xleft: "0",
		ytop: "0"
	} : t === "imagefield" ? e : t === "imagetrim" ? {
		...e,
		displaypolicy: "2"
	} : t === "stackfield" ? {
		childgravity: "9",
		orientation: "1",
		ismovebounded: "1",
		isresizebounded: "0",
		childbottommargin: "0",
		childleftmargin: "0",
		childrightmargin: "0",
		childtopmargin: "0",
		separatorwidth: "0",
		separatorstyle: "-1"
	} : t === "matrixfield" ? {
		childgravity: "18",
		collapsepolicy: "3",
		ismovebounded: "1",
		isresizebounded: "1",
		childbottommargin: "0",
		childleftmargin: "0",
		childrightmargin: "0",
		childtopmargin: "0"
	} : {};
}
//#endregion
//#region src/wml.ts
function n(e, t) {
	return {};
}
var r = (e) => e.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (e, t) => {
	if (t[0] === "#") {
		let e = t[1].toLowerCase() === "x" ? parseInt(t.slice(2), 16) : Number(t.slice(1));
		if (!Number.isInteger(e) || e <= 0 || e > 1114111 || e >= 55296 && e <= 57343) throw Error("Invalid XML character");
		return String.fromCodePoint(e);
	}
	return {
		amp: "&",
		lt: "<",
		gt: ">",
		quot: "\"",
		apos: "'"
	}[t.toLowerCase()];
}), i = (e, t) => e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, t === "\"" ? "&quot;" : "\"").replace(/'/g, t === "'" ? "&apos;" : "'").replace(/\r/g, "&#13;").replace(/\n/g, "&#10;").replace(/\t/g, "&#9;");
function a(e, t, n) {
	if (n.length > 8e6) throw Error("WML exceeds the 8 MB document limit");
	let i = [], a = [], o = /* @__PURE__ */ new Map(), s, c = 0;
	for (; c < n.length;) {
		let e = n.indexOf("<", c);
		if (e < 0) {
			if (!a.length && n.slice(c).trim()) throw Error("Text outside frame");
			break;
		}
		if (!a.length && n.slice(c, e).trim()) throw Error("Text outside frame");
		if (n.startsWith("<!--", e) || n.startsWith("<![CDATA[", e) || n.startsWith("<?", e)) {
			let t = n.startsWith("<!--", e) ? "-->" : n.startsWith("<?", e) ? "?>" : "]]>", r = n.indexOf(t, e + 2);
			if (r < 0) throw Error("Unterminated WML comment or data");
			c = r + t.length;
			continue;
		}
		if (n.startsWith("<!", e)) throw Error("DTD and external entities are unsupported");
		let t = e + 1, l = "";
		for (; t < n.length; t++) {
			let e = n[t];
			if (l) e === l && (l = "");
			else if (e === "\"" || e === "'") l = e;
			else if (e === ">") break;
		}
		if (t === n.length) throw Error("Unterminated WML tag");
		let u = n.slice(e, t + 1), d = /^<\/([\w:.-]+)\s*>$/.exec(u);
		if (d) {
			let i = a.pop();
			if (!i || i.kind !== d[1]) throw Error("Mismatched WML closing tag");
			i.end = t + 1, !i.children.length && i.kind !== "script" && (i.contentSpan = {
				start: i.openEnd,
				end: e
			}, i.value = r(n.slice(i.openEnd, e).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, (e, t) => t).replace(/<\?ingres_invalidxmlchar\s+(\d+)\s*\?>/g, (e, t) => String.fromCodePoint(Number(t)))));
		} else {
			let n = /^<([a-zA-Z_][\w:.-]*)/.exec(u);
			if (!n) throw Error("Invalid WML element");
			if (i.length >= 5e4 || a.length >= 128) throw Error("WML structure limit exceeded");
			let c = a.at(-1), l = `${c?.id ?? ""}/${n[1]}`, d = o.get(l) ?? 0;
			o.set(l, d + 1);
			let f = {
				id: `${l}[${d}]`,
				kind: n[1],
				parentId: c?.id,
				start: e,
				end: t + 1,
				openEnd: t + 1,
				insertAt: t - +!!u.endsWith("/>"),
				attributes: Object.create(null),
				children: []
			}, p = n[0].length, m = /\s+([a-zA-Z_][\w:.-]*)\s*=\s*(["'])([\s\S]*?)\2/gy;
			for (; p < u.length;) {
				m.lastIndex = p;
				let t = m.exec(u);
				if (!t) break;
				if (Object.hasOwn(f.attributes, t[1])) throw Error("Duplicate WML attribute");
				let n = e + t.index + t[0].indexOf(t[2]) + 1;
				if (f.attributes[t[1]] = {
					start: e + t.index,
					end: e + m.lastIndex,
					value: r(t[3]),
					quote: t[2],
					valueSpan: {
						start: n,
						end: n + t[3].length
					}
				}, t[1] === "gorak_style") throw Error("Retired gorak_style format; re-export with current gorak");
				p = m.lastIndex;
			}
			if (!/^\s*\/?\>$/.test(u.slice(p))) throw Error("Invalid WML attributes");
			if (c) c.children.push(f);
			else {
				if (s) throw Error("Multiple WML roots");
				s = f;
			}
			i.push(f), u.endsWith("/>") || a.push(f);
		}
		c = t + 1;
	}
	if (!s || s.kind !== "frame" || a.length) throw Error("Expected a complete WML frame");
	return {
		uri: e,
		version: t,
		text: n,
		root: s,
		nodes: i
	};
}
function o(e, n) {
	let r = { ...Object.fromEntries(Object.entries(t(e.kind)).map(([e, t]) => [e, {
		value: t,
		origin: "Native class default"
	}])) };
	delete r.name, e.kind !== "topform" && !e.attributes.gravity && (e.attributes.xleft || e.attributes.ytop) && (r.gravity = {
		value: "-1",
		origin: "OpenROAD positioned-field default"
	});
	for (let [t, n] of Object.entries(p(e))) r[t] = {
		value: n,
		origin: "WML"
	};
	return r;
}
function s(e, t, n, r) {
	if (!/^[a-zA-Z_][\w:.-]*$/.test(n) || n === "gorak_style") throw Error("Invalid or protected property");
	let a = e.nodes.find((e) => e.id === t);
	if (!a) throw Error("Field no longer exists");
	let o = a.attributes[n], s = a.children.find((e) => e.kind === n && e.value !== void 0 && e.kind !== "script"), c, l;
	if (s) {
		let t = r === null ? {
			start: s.start,
			end: s.end
		} : s.contentSpan;
		return {
			uri: e.uri,
			version: e.version,
			edits: [{
				...t,
				expected: e.text.slice(t.start, t.end),
				text: r === null ? "" : i(r, "\"").replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, (e) => `<?ingres_invalidxmlchar ${e.charCodeAt(0)}?>`)
			}]
		};
	}
	if (r === null) {
		if (!o) return {
			uri: e.uri,
			version: e.version,
			edits: []
		};
		c = o, l = "";
	} else o ? (c = o.valueSpan, l = i(r, o.quote)) : (c = {
		start: a.insertAt,
		end: a.insertAt
	}, l = ` ${n}="${i(r, "\"")}"`);
	return {
		uri: e.uri,
		version: e.version,
		edits: [{
			...c,
			text: l,
			expected: e.text.slice(c.start, c.end)
		}]
	};
}
function c(e, t, n, r, a = {}, o = {}) {
	if (!/^[a-z]+$/.test(t)) throw Error("Invalid field class");
	let s = e.root.children.find((e) => e.kind === "topform");
	if (!s) throw Error("No topform");
	let c = new Set(e.nodes.map((e) => e.attributes.name?.value)), u = 1;
	for (; c.has(`field${u}`);) u++;
	for (let [e, t] of Object.entries(r)) if (![
		"xleft",
		"ytop",
		"width",
		"height"
	].includes(e) || !Number.isInteger(t) || Math.abs(t) > 1e6 || ["width", "height"].includes(e) && t < 1) throw Error("Invalid field geometry");
	let d = {
		...t === "palettefield" ? { curenumindex: "1" } : {},
		...a,
		name: `field${u}`,
		designbias: "3",
		...Object.fromEntries(Object.entries(r).map(([e, t]) => [e, String(t)]))
	};
	delete d.gorak_style;
	for (let e of Object.keys(d)) if (!/^[a-z][a-z0-9_]*$/.test(e)) throw Error("Invalid creation property");
	n !== void 0 && (d.fieldstyle = "0");
	let f = e.text.includes("\r\n") ? "\r\n" : "\n", p = /^[ \t]*/.exec(e.text.slice(e.text.lastIndexOf("\n", s.start) + 1, s.start))[0], m = `${p}  <${t}${Object.entries(d).map(([e, t]) => ` ${e}="${i(t, "\"")}"`).join("")}${Object.keys(o).length ? `>${Object.entries(o).map(([e, t]) => l(e, t)).join("")}</${t}>` : "/>"}`;
	if (s.end === s.openEnd) {
		let t = s.insertAt;
		return {
			uri: e.uri,
			version: e.version,
			edits: [{
				start: t,
				end: s.openEnd,
				expected: e.text.slice(t, s.openEnd),
				text: `>${f}${m}${f}${p}</topform>`
			}]
		};
	}
	let h = e.text.lastIndexOf("</", s.end - 1), g = e.text.lastIndexOf("\n", h) + 1, _ = e.text.slice(g, h).trim() === "" ? g : h;
	return {
		uri: e.uri,
		version: e.version,
		edits: [{
			start: _,
			end: _,
			expected: "",
			text: `${m}${f}`
		}]
	};
}
function l(e, t, n = 0) {
	if (n > 128 || !/^[a-z][a-z0-9_]*$/.test(e)) throw Error("Invalid structured creation data");
	if (typeof t == "string") {
		if (t.length > 1e6) throw Error("Structured value too large");
		return e === "script" ? `<script><![CDATA[${t.replaceAll("]]>", "]]]]><![CDATA[>")}]]><\/script>` : `<${e}>${i(t, "\"").replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, (e) => `<?ingres_invalidxmlchar ${e.charCodeAt(0)}?>`)}</${e}>`;
	}
	if (!t || typeof t != "object" || Array.isArray(t)) throw Error("Expected structured object");
	let r = [], a = [], o = t;
	if (e === "childfields" || e === "childmenufields") {
		let e = o.row;
		if (!Array.isArray(e)) throw Error("Expected native child rows");
		return e.map((e) => {
			if (!e || typeof e != "object" || typeof e.type != "string") throw Error("Child field needs its native type");
			return l(e.type, e, n + 1);
		}).join("");
	}
	for (let [t, s] of Object.entries(o)) if (t !== "type" || e === "protofield") {
		if (!/^[a-z][a-z0-9_]*$/.test(t)) throw Error("Invalid creation property");
		if (typeof s == "string") r.push(` ${t}="${i(s, "\"")}"`);
		else if (Array.isArray(s)) {
			if (s.length > 1e4) throw Error("Too many structured rows");
			a.push(...s.map((e) => l(t, e, n + 1)));
		} else a.push(l(t, s, n + 1));
	}
	return `<${e}${r.join("")}${a.length ? `>${a.join("")}</${e}>` : "/>"}`;
}
function u(e, t) {
	if (e.uri !== t.uri || e.version !== t.version) throw Error("Stale document edit");
	let n = e.text, r = n.length;
	for (let e of [...t.edits].sort((e, t) => t.start - e.start)) {
		if (!Number.isInteger(e.start) || !Number.isInteger(e.end) || e.start < 0 || e.end < e.start || e.end > r || n.slice(e.start, e.end) !== e.expected) throw Error("Invalid or overlapping source edit");
		n = n.slice(0, e.start) + e.text + n.slice(e.end), r = e.start;
	}
	return a(e.uri, e.version + 1, n);
}
function d(e, t) {
	let n = new Set(t), r = new Map(e.nodes.map((e) => [e.id, e]));
	return t.map((t) => {
		let n = r.get(t);
		if (!n || n.kind === "topform" || n === e.root) throw Error("Selection is not a field");
		return n;
	}).filter((e, t, i) => {
		if (i.indexOf(e) !== t) return !1;
		let a = r.get(e.parentId ?? "");
		for (; a;) {
			if (n.has(a.id)) return !1;
			a = r.get(a.parentId ?? "");
		}
		return !0;
	});
}
function f(e, t) {
	return {
		uri: e.uri,
		version: e.version,
		edits: d(e, t).map((t) => ({
			start: t.start,
			end: t.end,
			expected: e.text.slice(t.start, t.end),
			text: ""
		}))
	};
}
function p(e) {
	return {
		...Object.fromEntries(Object.entries(e.attributes).map(([e, t]) => [e, t.value])),
		...Object.fromEntries(e.children.filter((e) => e.kind !== "script" && e.value !== void 0).map((e) => [e.kind, e.value]))
	};
}
//#endregion
//#region src/metadata.ts
function m(e, t, n) {
	if (n.length > 8e6) throw Error("Companion metadata exceeds 8 MB");
	let r = /^\[(?:framesource|frametemplate)\][ \t]*\r?$/m.exec(n);
	if (!r) throw Error("Companion source has no framesource or frametemplate section");
	let i = r.index + r[0].length, a = n.slice(i), o = /^[ \t]*(?:\[|===)/m.exec(a), s = o ? i + o.index : n.length, c = Object.create(null), l = /^([a-zA-Z_][\w]*)[ \t]*=[ \t]*("(?:\\.|[^"\\])*"|'[^']*'|[^#\r\n]+?)[ \t]*(?:#.*)?\r?$/gm, u = n.slice(i, s);
	for (let e of u.matchAll(l)) {
		let t = e[2], n = i + e.index + e[0].indexOf(t, e[1].length);
		if (c[e[1]]) throw Error("Duplicate frame metadata property");
		let r = t.startsWith("\"") ? JSON.parse(t) : t.startsWith("'") ? t.slice(1, -1) : t.trim();
		c[e[1]] = {
			start: i + e.index,
			end: i + e.index + e[0].length,
			value: String(r),
			valueSpan: {
				start: n,
				end: n + t.length
			},
			quote: ""
		};
	}
	return {
		uri: e,
		version: t,
		text: n,
		attributes: c,
		insertAt: s
	};
}
function h(e, t) {
	let n = [], r = [];
	for (let [i, a] of Object.entries(t)) {
		if (!/^[a-z][a-z0-9_]*$/.test(i)) throw Error("Invalid metadata property");
		let t = e.attributes[i];
		a === null ? t && n.push({
			start: t.start,
			end: t.valueSpan.end,
			expected: e.text.slice(t.start, t.valueSpan.end),
			text: ""
		}) : t ? n.push({
			...t.valueSpan,
			expected: e.text.slice(t.valueSpan.start, t.valueSpan.end),
			text: JSON.stringify(a)
		}) : r.push(`${i} = ${JSON.stringify(a)}`);
	}
	if (r.length) {
		let t = e.text.includes("\r\n") ? "\r\n" : "\n";
		n.push({
			start: e.insertAt,
			end: e.insertAt,
			expected: "",
			text: (e.insertAt > 0 && e.text[e.insertAt - 1] !== "\n" ? t : "") + r.join(t) + t
		});
	}
	return {
		uri: e.uri,
		version: e.version,
		edits: n
	};
}
function g(e, t) {
	if (t.uri !== e.uri || t.version !== e.version) throw Error("Stale metadata edit");
	let n = e.text, r = n.length;
	for (let e of [...t.edits].sort((e, t) => t.start - e.start)) {
		if (e.start < 0 || e.end > r || e.end < e.start || n.slice(e.start, e.end) !== e.expected) throw Error("Invalid metadata edit");
		n = n.slice(0, e.start) + e.text + n.slice(e.end), r = e.start;
	}
	return m(e.uri, e.version + 1, n);
}
var _ = {
	standalone: !0,
	properties: { row_class: "formfield" },
	group_order: /* @__PURE__ */ "barfield.boxtrim.buttonfield.controlbutton.ellipseshape.entryfield.entryfield:2.extobjfield.flexibleform.freetrim.imagefield.imagetrim.listfield.listviewfield.matrixfield.optionfield.palettefield.popupbutton.radiofield.rectangleshape.scrollbarfield.segmentshape.sliderfield.stackfield.subform.tabfolder.tablefield.togglefield.treeviewfield.viewportfield".split("."),
	groups: /* @__PURE__ */ JSON.parse("{\"barfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"barfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"barfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"i4\",\"defaultvalue\":\"3\",\"defaultstring\":\"0\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"740\",\"height\":\"521\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"fgpattern\":\"-1\",\"growfrom\":\"6\"}}},\"boxtrim\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"boxtrim\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"boxtrim\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"varchar(100)\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"490\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"gravity\":\"17\",\"requirerealfield\":\"1\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"7\",\"lines\":\"1\",\"stringvalue\":\"Box trim\"}}},\"buttonfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"buttonfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"buttonfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"i4\",\"defaultvalue\":\"1\",\"bgcolor\":\"70\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"979\",\"height\":\"302\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"textlabel\":\"Button\"}}},\"controlbutton\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"controlbutton\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"controlbutton\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"70\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"135\",\"height\":\"135\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinestyle\":\"1\",\"outlinewidth\":\"7\",\"optionmenu\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"8192\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\"},\"popupalignment\":\"0\"}}},\"ellipseshape\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"ellipseshape\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"ellipseshape\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"i4\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"823\",\"height\":\"281\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\"}}},\"entryfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"entryfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"entryfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"varchar(100)\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"917\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"4\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"charsperline\":\"14\",\"lines\":\"1\"}}},\"entryfield:2\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"entryfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"entryfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"varchar(100)\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"896\",\"height\":\"313\",\"designbias\":\"1\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"hasscrollbar\":\"1\",\"charsperline\":\"11\",\"lines\":\"2\"}}},\"extobjfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"extobjfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"extobjfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"521\",\"height\":\"521\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"4\",\"outlinecolor\":\"1\"}}},\"flexibleform\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"flexibleform\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"flexibleform\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"771\",\"height\":\"354\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"ismovebounded\":\"0\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"656\",\"ytop\":\"177\",\"width\":\"115\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"1\",\"lines\":\"1\",\"stringvalue\":\"B\"},\"row2\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"width\":\"115\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"1\",\"lines\":\"1\",\"stringvalue\":\"A\"}},\"row_class\":\"formfield\"}}}},\"freetrim\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"freetrim\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"varchar(100)\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"458\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"7\",\"lines\":\"1\",\"stringvalue\":\"Free trim\"}}},\"imagefield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"imagefield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"imagefield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"bitmapobject\",\"isnullable\":\"1\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"552\",\"height\":\"385\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"displaypolicy\":\"1\"}}},\"imagetrim\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"imagetrim\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"imagetrim\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"bitmapobject\",\"isnullable\":\"1\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"240\",\"height\":\"240\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"image\":{\"obj_encoded\":\"12:bitmapobject\\n0\\n1\\n9\\n69\\n12:ImagTrm3.BMP\\n0\\n1\\n2\\n0\\n23\\n23\\n2\\n0\\n69\\nr3007ffffc4000044003744001c44007f4400494400084403784401c84407f84\\n40498440088441848443c48447e4844ff2845ffa847ffe847ffffcr300\\n0\\n0\\n0\\n0\\n0\\n-1\\n0\\n0\\n0\\n0\\n-1:\\n-1:\\n\"}}}},\"listfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"listfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"listfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"defaultvalue\":\"3\",\"defaultstring\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"969\",\"height\":\"563\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"valuelist\":{\"choiceitems\":{\"row\":{\"row1\":{\"enumdisplay\":\"First Item\",\"enumtext\":\"First Item\",\"enumvalue\":\"1\"},\"row2\":{\"enumdisplay\":\"Second Item\",\"enumtext\":\"Second Item\",\"enumvalue\":\"2\"},\"row3\":{\"enumdisplay\":\"Third Item\",\"enumtext\":\"Third Item\",\"enumvalue\":\"3\"},\"row4\":{\"enumdisplay\":\"Fourth Item\",\"enumtext\":\"Fourth Item\",\"enumvalue\":\"4\"},\"row5\":{\"enumdisplay\":\"Fifth Item\",\"enumtext\":\"Fifth Item\",\"enumvalue\":\"5\"},\"row6\":{\"enumdisplay\":\"Sixth Item\",\"enumtext\":\"Sixth Item\",\"enumvalue\":\"6\"}},\"row_class\":\"choicedetail\"}},\"typeface\":\"0\",\"typesize\":\"8\",\"visiblerows\":\"4\"}}},\"listviewfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"listviewfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"listviewfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"521\",\"height\":\"521\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"valuelist\":\"\",\"typeface\":\"0\",\"typesize\":\"8\",\"colattributes\":{\"row\":{\"row1\":{\"columnwidth\":\"1500\",\"headertext\":\"Column 1\"},\"row2\":{\"columnwidth\":\"1500\",\"headertext\":\"Column 2\"}},\"row_class\":\"listviewcolattr\"},\"style\":\"4\",\"largeimageheight\":\"32\",\"largeimagewidth\":\"32\",\"smallimageheight\":\"16\",\"smallimagewidth\":\"16\"}}},\"matrixfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"matrixfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"2\"},\"styles\":{\"style1\":{\"_type\":\"matrixfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"594\",\"height\":\"354\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"42\",\"width\":\"250\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"3\",\"lines\":\"1\",\"stringvalue\":\"One\"},\"row2\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"1\",\"column\":\"2\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"333\",\"width\":\"260\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"4\",\"lines\":\"1\",\"stringvalue\":\"Two\"},\"row3\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"2\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"177\",\"width\":\"333\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"5\",\"lines\":\"1\",\"stringvalue\":\"Three\"},\"row4\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"2\",\"column\":\"2\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"333\",\"ytop\":\"177\",\"width\":\"260\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"4\",\"lines\":\"1\",\"stringvalue\":\"Four\"}}},\"collapsepolicy\":\"3\",\"columns\":\"2\",\"rows\":\"2\",\"separatorwidth\":\"0\"},\"style2\":{\"_type\":\"matrixfield\",\"_attributes\":{\"row\":\"2\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"521\",\"width\":\"604\",\"height\":\"365\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"fieldstyle\":\"2\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"42\",\"width\":\"250\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"3\",\"lines\":\"1\",\"stringvalue\":\"One\"},\"row2\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"1\",\"column\":\"2\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"344\",\"width\":\"260\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"4\",\"lines\":\"1\",\"stringvalue\":\"Two\"},\"row3\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"2\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"188\",\"width\":\"333\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"5\",\"lines\":\"1\",\"stringvalue\":\"Three\"},\"row4\":{\"_type\":\"freetrim\",\"_attributes\":{\"row\":\"2\",\"column\":\"2\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"344\",\"ytop\":\"188\",\"width\":\"260\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"4\",\"lines\":\"1\",\"stringvalue\":\"Four\"}}},\"collapsepolicy\":\"3\",\"columns\":\"2\",\"rows\":\"2\"}}},\"optionfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"optionfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"optionfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"defaultvalue\":\"3\",\"defaultstring\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"1000\",\"height\":\"208\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"valuelist\":{\"choiceitems\":{\"row\":{\"row1\":{\"enumdisplay\":\"First Item\",\"enumtext\":\"First Item\",\"enumvalue\":\"1\"},\"row2\":{\"enumdisplay\":\"Second Item\",\"enumtext\":\"Second Item\",\"enumvalue\":\"2\"},\"row3\":{\"enumdisplay\":\"Third Item\",\"enumtext\":\"Third Item\",\"enumvalue\":\"3\"}},\"row_class\":\"choicedetail\"}},\"curenumindex\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\"}}},\"palettefield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"palettefield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"palettefield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"defaultvalue\":\"3\",\"defaultstring\":\"1\",\"bgcolor\":\"70\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"510\",\"height\":\"771\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"valuelist\":{\"choiceitems\":{\"row\":{\"row1\":{\"enumvalue\":\"1\",\"enumbitmap\":{\"obj_encoded\":\"12:bitmapobject\\n0\\n1\\n9\\n60\\n64:/m/hound/fe6/wgl/front/apped/grant/src/apped/Icons/pal_icon1.xbm\\n0\\n1\\n2\\n0\\n20\\n20\\n2\\n0\\n60\\nR1190070000070000070R11c00\\n0\\n0\\n0\\n0\\n0\\n-1\\n0\\n0\\n0\\n0\\n-1:\\n-1:\\n\"}},\"row2\":{\"enumvalue\":\"2\",\"enumbitmap\":{\"obj_encoded\":\"12:bitmapobject\\n0\\n1\\n9\\n60\\n64:/m/hound/fe6/wgl/front/apped/grant/src/apped/Icons/pal_icon2.xbm\\n0\\n1\\n2\\n0\\n20\\n20\\n2\\n0\\n60\\nra0007000007000007R113000e00000e00000erb00\\n0\\n0\\n0\\n0\\n0\\n-1\\n0\\n0\\n0\\n0\\n-1:\\n-1:\\n\"}},\"row3\":{\"enumvalue\":\"3\",\"enumbitmap\":{\"obj_encoded\":\"12:bitmapobject\\n0\\n1\\n9\\n60\\n64:/m/hound/fe6/wgl/front/apped/grant/src/apped/Icons/pal_icon3.xbm\\n0\\n1\\n2\\n0\\n20\\n20\\n2\\n0\\n60\\nr3001c00001c00001cr90070000070000070r80001c00001c00001c0r600\\n0\\n0\\n0\\n0\\n0\\n-1\\n0\\n0\\n0\\n0\\n-1:\\n-1:\\n\"}},\"row4\":{\"enumvalue\":\"4\",\"enumbitmap\":{\"obj_encoded\":\"12:bitmapobject\\n0\\n1\\n9\\n60\\n64:/m/hound/fe6/wgl/front/apped/grant/src/apped/Icons/pal_icon4.xbm\\n0\\n1\\n2\\n0\\n20\\n20\\n2\\n0\\n60\\nr9000e07000e07000e07R113000e07000e07000e07ra00\\n0\\n0\\n0\\n0\\n0\\n-1\\n0\\n0\\n0\\n0\\n-1:\\n-1:\\n\"}},\"row5\":{\"enumvalue\":\"5\",\"enumbitmap\":{\"obj_encoded\":\"12:bitmapobject\\n0\\n1\\n9\\n60\\n64:/m/hound/fe6/wgl/front/apped/grant/src/apped/Icons/pal_icon5.xbm\\n0\\n1\\n2\\n0\\n20\\n20\\n2\\n0\\n60\\nr3001c01c01c01c01c01c0r70070000070000070r7001c01c01c01c01c01c0r6\\n00\\n0\\n0\\n0\\n0\\n0\\n-1\\n0\\n0\\n0\\n0\\n-1:\\n-1:\\n\"}},\"row6\":{\"enumvalue\":\"6\",\"enumbitmap\":{\"obj_encoded\":\"12:bitmapobject\\n0\\n1\\n9\\n60\\n64:/m/hound/fe6/wgl/front/apped/grant/src/apped/Icons/pal_icon6.xbm\\n0\\n1\\n2\\n0\\n20\\n20\\n2\\n0\\n60\\nr3000e07000e07000e07r7000e07000e07000e07r7000e07000e07000e07r700\\n0\\n0\\n0\\n0\\n0\\n-1\\n0\\n0\\n0\\n0\\n-1:\\n-1:\\n\"}}},\"row_class\":\"choicedetail\"}},\"columns\":\"2\"}}},\"popupbutton\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"popupbutton\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"popupbutton\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"70\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"1042\",\"height\":\"281\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"requirerealfield\":\"1\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"typeface\":\"0\",\"typesize\":\"8\",\"textlabel\":\"Popup Button\",\"optionmenu\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"8192\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\"}}}},\"radiofield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"radiofield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"radiofield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"defaultvalue\":\"3\",\"defaultstring\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"937\",\"height\":\"698\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"valuelist\":{\"choiceitems\":{\"row\":{\"row1\":{\"enumdisplay\":\"First Item\",\"enumtext\":\"First Item\",\"enumvalue\":\"1\"},\"row2\":{\"enumdisplay\":\"Second Item\",\"enumtext\":\"Second Item\",\"enumvalue\":\"2\"},\"row3\":{\"enumdisplay\":\"Third Item\",\"enumtext\":\"Third Item\",\"enumvalue\":\"3\"}},\"row_class\":\"choicedetail\"}},\"typeface\":\"0\",\"typesize\":\"8\",\"columns\":\"1\"}}},\"rectangleshape\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"rectangleshape\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"2\"},\"styles\":{\"style1\":{\"_type\":\"rectangleshape\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"i4\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"812\",\"height\":\"240\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\"},\"style2\":{\"_type\":\"rectangleshape\",\"_attributes\":{\"row\":\"2\",\"column\":\"1\"},\"datatype\":\"i4\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"427\",\"width\":\"833\",\"height\":\"271\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"gravity\":\"17\",\"fieldstyle\":\"2\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"linewidth\":\"0\"}}},\"scrollbarfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"scrollbarfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"scrollbarfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"i4\",\"defaultvalue\":\"3\",\"defaultstring\":\"0\",\"bgcolor\":\"25\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"1302\",\"height\":\"167\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"elevatorsize\":\"20\",\"orientation\":\"2\"}}},\"segmentshape\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"segmentshape\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"segmentshape\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"844\",\"height\":\"292\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"gravity\":\"17\",\"bgpattern\":\"2\",\"bgdisplaypolicy\":\"2\",\"point1x\":\"271\",\"point1y\":\"52\",\"point2x\":\"1094\",\"point2y\":\"323\"}}},\"sliderfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"sliderfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"sliderfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"i4\",\"defaultvalue\":\"3\",\"defaultstring\":\"0\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"1156\",\"height\":\"292\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"orientation\":\"2\",\"typeface\":\"0\",\"typesize\":\"8\"}}},\"stackfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"stackfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"2\"},\"styles\":{\"style1\":{\"_type\":\"stackfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"333\",\"height\":\"531\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"width\":\"250\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"3\",\"lines\":\"1\",\"stringvalue\":\"One\"},\"row2\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"177\",\"width\":\"260\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"4\",\"lines\":\"1\",\"stringvalue\":\"Two\"},\"row3\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"354\",\"width\":\"333\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"5\",\"lines\":\"1\",\"stringvalue\":\"Three\"}},\"row_class\":\"formfield\"},\"separatorstyle\":\"-1\",\"separatorwidth\":\"0\"},\"style2\":{\"_type\":\"stackfield\",\"_attributes\":{\"row\":\"2\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"698\",\"width\":\"333\",\"height\":\"552\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"fieldstyle\":\"2\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"width\":\"250\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"3\",\"lines\":\"1\",\"stringvalue\":\"One\"},\"row2\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"188\",\"width\":\"260\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"4\",\"lines\":\"1\",\"stringvalue\":\"Two\"},\"row3\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"375\",\"width\":\"333\",\"height\":\"177\",\"designbias\":\"256\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"5\",\"lines\":\"1\",\"stringvalue\":\"Three\"}},\"row_class\":\"formfield\"},\"separatorstyle\":\"-1\",\"separatorwidth\":\"-1\"}}},\"subform\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"subform\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"subform\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"958\",\"height\":\"365\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"isresizebounded\":\"1\"}}},\"tabfolder\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"tabfolder\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"tabfolder\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"979\",\"height\":\"781\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"isresizebounded\":\"1\",\"tabbar\":{\"bgcolor\":\"35\",\"fgcolor\":\"4\",\"width\":\"521\",\"height\":\"521\",\"designbias\":\"256\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"83\",\"isresizebounded\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"selectedtypeface\":\"0\",\"selectedtypesize\":\"8\",\"tabfieldarray\":{\"row\":{\"row1\":{\"bgcolor\":\"35\",\"fgcolor\":\"4\",\"xleft\":\"250\",\"width\":\"521\",\"height\":\"521\",\"designbias\":\"256\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"hastextlabel\":\"1\",\"textlabel\":\"Page1\"},\"row2\":{\"bgcolor\":\"35\",\"fgcolor\":\"4\",\"xleft\":\"635\",\"width\":\"521\",\"height\":\"521\",\"designbias\":\"256\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"hastextlabel\":\"1\",\"textlabel\":\"Page2\"},\"row3\":{\"bgcolor\":\"35\",\"fgcolor\":\"4\",\"xleft\":\"1021\",\"width\":\"521\",\"height\":\"521\",\"designbias\":\"256\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"hastextlabel\":\"1\",\"textlabel\":\"Page3\"}},\"row_class\":\"tabfield\"}},\"tabpagearray\":{\"row\":{\"row1\":{\"name\":\"page1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"208\",\"width\":\"969\",\"height\":\"563\",\"designbias\":\"256\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"isresizebounded\":\"1\",\"delaymkwidget\":\"1\"},\"row2\":{\"name\":\"page2\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"208\",\"width\":\"969\",\"height\":\"563\",\"designbias\":\"256\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"isresizebounded\":\"1\",\"delaymkwidget\":\"1\"},\"row3\":{\"name\":\"page3\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"208\",\"width\":\"969\",\"height\":\"563\",\"designbias\":\"256\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"isresizebounded\":\"1\",\"delaymkwidget\":\"1\"}},\"row_class\":\"tabpage\"}}}},\"tablefield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"tablefield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"2\"},\"styles\":{\"style1\":{\"_type\":\"tablefield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"isarray\":\"1\",\"isnullable\":\"1\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield initialize */\\n\\ninitialize =\\ndeclare\\n#   include _tfInitDecl\\nenddeclare\\n{\\n#   include _tfInit\\n}\\n\\n\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"781\",\"height\":\"1135\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"columnsdisplayed\":\"1\",\"controlbutton\":{\"name\":\"field2_controlbutton\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"615\",\"ytop\":\"198\",\"width\":\"135\",\"height\":\"135\",\"designbias\":\"2\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"16\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinestyle\":\"1\",\"outlinewidth\":\"7\",\"optionmenu\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"childmenufields\":{\"row\":{\"row1\":{\"_type\":\"menubutton\",\"name\":\"insertbefore\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Insert Before Current Row */\\n\\non click =\\n{\\n#   include _tfcbInsClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"2\",\"textlabel\":\"Insert Before Current Row\",\"speedkey\":\"-13\"},\"row2\":{\"_type\":\"menubutton\",\"name\":\"deletecurrent\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Delete Current Row */\\n\\non click =\\n{\\n#   include _tfcbDelClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"1\",\"textlabel\":\"Delete Current Row\",\"speedkey\":\"-12\"},\"row3\":{\"_type\":\"menubutton\",\"name\":\"deleteall\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Delete All Rows */\\n\\non click =\\n{\\n#   include _tfcbDelAllClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"1\",\"textlabel\":\"Delete All Rows\"},\"row4\":{\"_type\":\"menubutton\",\"name\":\"copytable\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Copy Table */\\n\\ninitialize =\\n{\\n#   include _tfcbCopyTableInit\\n}\\n\\non click =\\n{\\n#   include _tfcbCopyTableClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"1\",\"textlabel\":\"Copy Table...\"}},\"row_class\":\"menufield\"}},\"popupalignment\":\"0\"},\"numvisiblerows\":\"4\",\"updateops\":\"2\",\"queryops\":\"2\",\"tablebody\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"375\",\"width\":\"604\",\"height\":\"740\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"16\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinewidth\":\"1\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"columnfield\",\"name\":\"field1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"width\":\"604\",\"height\":\"740\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinestyle\":\"1\",\"outlinewidth\":\"0\",\"protofield\":{\"_type\":\"entryfield\",\"name\":\"field1\",\"datatype\":\"varchar(100)\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"width\":\"604\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"4\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"typeface\":\"0\",\"typesize\":\"8\",\"charsperline\":\"9\",\"lines\":\"1\"}}},\"row_class\":\"formfield\"},\"orientation\":\"2\"},\"tableheader\":{\"bgcolor\":\"2\",\"fgcolor\":\"2\",\"ytop\":\"177\",\"width\":\"604\",\"height\":\"177\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"256\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"2\",\"outlinewidth\":\"1\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"94\",\"width\":\"406\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"2\",\"outlinewidth\":\"0\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"6\",\"lines\":\"1\",\"stringvalue\":\"Col Hdr\"}},\"row_class\":\"formfield\"},\"orientation\":\"2\",\"childgravity\":\"10\",\"separatorcolor\":\"2\"},\"titletrim\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"21\",\"width\":\"583\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"9\",\"lines\":\"1\",\"stringvalue\":\"Table Field\"}},\"style2\":{\"_type\":\"tablefield\",\"_attributes\":{\"row\":\"2\",\"column\":\"1\"},\"isarray\":\"1\",\"isnullable\":\"1\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield initialize */\\n\\ninitialize =\\ndeclare\\n#   include _tfInitDecl\\nenddeclare\\n{\\n#   include _tfInit\\n}\\n\\n\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"1302\",\"width\":\"781\",\"height\":\"1104\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"2\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"colseparatorwidth\":\"0\",\"rowseparatorwidth\":\"0\",\"columnsdisplayed\":\"1\",\"controlbutton\":{\"name\":\"field2_controlbutton\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"615\",\"ytop\":\"198\",\"width\":\"135\",\"height\":\"135\",\"designbias\":\"2\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"16\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinestyle\":\"1\",\"outlinewidth\":\"7\",\"optionmenu\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"childmenufields\":{\"row\":{\"row1\":{\"_type\":\"menubutton\",\"name\":\"insertbefore\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Insert Before Current Row */\\n\\non click =\\n{\\n#   include _tfcbInsClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"2\",\"textlabel\":\"Insert Before Current Row\",\"speedkey\":\"-13\"},\"row2\":{\"_type\":\"menubutton\",\"name\":\"deletecurrent\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Delete Current Row */\\n\\non click =\\n{\\n#   include _tfcbDelClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"1\",\"textlabel\":\"Delete Current Row\",\"speedkey\":\"-12\"},\"row3\":{\"_type\":\"menubutton\",\"name\":\"deleteall\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Delete All Rows */\\n\\non click =\\n{\\n#   include _tfcbDelAllClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"1\",\"textlabel\":\"Delete All Rows\"},\"row4\":{\"_type\":\"menubutton\",\"name\":\"copytable\",\"script\":\"\\n/*----------------------------------------------*/\\n/* tablefield controlbutton menuitem Copy Table */\\n\\ninitialize =\\n{\\n#   include _tfcbCopyTableInit\\n}\\n\\non click =\\n{\\n#   include _tfcbCopyTableClick\\n}\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"designbias\":\"16384\",\"trimbias\":\"16384\",\"updatebias\":\"16384\",\"querybias\":\"16384\",\"readbias\":\"16384\",\"user1bias\":\"16384\",\"user2bias\":\"16384\",\"user3bias\":\"16384\",\"focusbehavior\":\"1\",\"textlabel\":\"Copy Table...\"}},\"row_class\":\"menufield\"}},\"popupalignment\":\"0\"},\"numvisiblerows\":\"4\",\"updateops\":\"2\",\"queryops\":\"2\",\"tablebody\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"ytop\":\"375\",\"width\":\"604\",\"height\":\"708\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"16\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinewidth\":\"1\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"columnfield\",\"name\":\"field1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"width\":\"604\",\"height\":\"708\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinestyle\":\"1\",\"outlinewidth\":\"0\",\"separatorwidth\":\"0\",\"protofield\":{\"_type\":\"entryfield\",\"name\":\"field1\",\"datatype\":\"varchar(100)\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"width\":\"604\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"4\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"typeface\":\"0\",\"typesize\":\"8\",\"charsperline\":\"9\",\"lines\":\"1\"}}},\"row_class\":\"formfield\"},\"orientation\":\"2\",\"separatorwidth\":\"0\"},\"tableheader\":{\"bgcolor\":\"2\",\"fgcolor\":\"2\",\"ytop\":\"177\",\"width\":\"604\",\"height\":\"177\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"256\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"2\",\"outlinewidth\":\"1\",\"childfields\":{\"row\":{\"row1\":{\"_type\":\"freetrim\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"94\",\"width\":\"406\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"2\",\"outlinewidth\":\"0\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"6\",\"lines\":\"1\",\"stringvalue\":\"Col Hdr\"}},\"row_class\":\"formfield\"},\"orientation\":\"2\",\"childgravity\":\"10\",\"separatorcolor\":\"2\",\"separatorwidth\":\"0\"},\"titletrim\":{\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"21\",\"width\":\"583\",\"height\":\"177\",\"designbias\":\"1\",\"trimbias\":\"16\",\"updatebias\":\"256\",\"querybias\":\"256\",\"readbias\":\"256\",\"user1bias\":\"256\",\"user2bias\":\"256\",\"user3bias\":\"256\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"3\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"ismultiline\":\"1\",\"charsperline\":\"9\",\"lines\":\"1\",\"stringvalue\":\"Table Field\"}}}},\"togglefield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"togglefield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"togglefield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"defaultvalue\":\"3\",\"defaultstring\":\"0\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"823\",\"height\":\"177\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"2\",\"outlinecolor\":\"1\",\"typeface\":\"0\",\"typesize\":\"8\",\"textlabel\":\"Toggle Item\",\"isautosized\":\"1\"}}},\"treeviewfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"treeviewfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"treeviewfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"datatype\":\"integer\",\"defaultvalue\":\"1\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"1062\",\"height\":\"1063\",\"designbias\":\"4\",\"trimbias\":\"256\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"bgdisplaypolicy\":\"2\",\"focusbehavior\":\"4\",\"outlinecolor\":\"1\",\"outlinestyle\":\"4\",\"typeface\":\"0\",\"typesize\":\"8\",\"hashorizontalscrollbar\":\"1\"}}},\"viewportfield\":{\"properties\":{\"_type\":\"matrixfield\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"clienttext\":\"viewportfield\",\"width\":\"10416\",\"height\":\"10417\",\"designbias\":\"2\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"fieldstyle\":\"0\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"childfields\":\"\",\"columns\":\"1\",\"rows\":\"1\"},\"styles\":{\"style1\":{\"_type\":\"viewportfield\",\"_attributes\":{\"row\":\"1\",\"column\":\"1\"},\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"271\",\"ytop\":\"52\",\"width\":\"1010\",\"height\":\"708\",\"designbias\":\"4\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"gravity\":\"17\",\"bgpattern\":\"-1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"viewfield\":{\"_type\":\"flexibleform\",\"bgcolor\":\"2\",\"fgcolor\":\"1\",\"xleft\":\"10\",\"ytop\":\"10\",\"width\":\"1000\",\"height\":\"1000\",\"designbias\":\"256\",\"trimbias\":\"8\",\"updatebias\":\"16\",\"querybias\":\"16\",\"readbias\":\"32\",\"user1bias\":\"16\",\"user2bias\":\"16\",\"user3bias\":\"16\",\"bgpattern\":\"1\",\"focusbehavior\":\"1\",\"outlinecolor\":\"1\",\"outlinewidth\":\"0\",\"ismovebounded\":\"0\"}}}}}")
}, v = (e) => !!e && typeof e == "object" && !Array.isArray(e), y = (e, t, n) => Object.defineProperty(e, t, {
	value: n,
	writable: !0,
	enumerable: !0,
	configurable: !0
});
function b(e, t, n = 0) {
	if (n > 128) throw Error("Stylesheet nesting limit exceeded");
	let r = structuredClone(e);
	for (let [e, i] of Object.entries(t)) if (!["$order", "$before"].includes(e)) {
		if (i === null) {
			if (!Object.hasOwn(r, e)) throw Error("Cannot remove absent stylesheet property");
			delete r[e];
		} else y(r, e, v(i) ? b(v(r[e]) ? r[e] : {}, i, n + 1) : structuredClone(i));
	}
	if (t.$before !== void 0) {
		if (!v(t.$before)) throw Error("Invalid stylesheet insertion hints");
		let e = new Map(Object.entries(t.$before)), n = Object.keys(r);
		for (let [t, n] of e) if (typeof n != "string" || t === n || !Object.hasOwn(r, t) || !Object.hasOwn(r, n)) throw Error("Invalid stylesheet insertion hint");
		for (; e.size;) {
			let t = [...e].filter(([, t]) => !e.has(t));
			if (!t.length) throw Error("Cyclic stylesheet insertion hints");
			for (let [r, i] of t) e.delete(r), n.splice(n.indexOf(r), 1), n.splice(n.indexOf(i), 0, r);
		}
		r = Object.fromEntries(n.map((e) => [e, r[e]]));
	}
	if (t.$order !== void 0) {
		let e = t.$order;
		if (!Array.isArray(e) || e.some((e) => typeof e != "string") || new Set(e).size !== e.length || e.length !== Object.keys(r).length || e.some((e) => !Object.hasOwn(r, e))) throw Error("Invalid stylesheet property order");
		r = Object.fromEntries(e.map((e) => [e, r[e]]));
	}
	return r;
}
function x(e, t) {
	if (!v(e)) throw Error("Expected numbered stylesheet slots");
	let n = Array.from({ length: Object.keys(e).length }, (e, n) => `${t}${n + 1}`);
	if (n.some((t) => !Object.hasOwn(e, t))) throw Error("Stylesheet slots must be contiguous");
	return n;
}
function S(e) {
	let t = structuredClone(_);
	delete t.standalone;
	for (let { defaults: n } of e) {
		if (!v(n) || Object.keys(n).some((e) => ![
			"standalone",
			"properties",
			"group_order",
			"groups",
			"$before",
			"$order"
		].includes(e))) throw Error("Unsupported stylesheet format; re-export with current gorak");
		let { standalone: e, ...r } = n;
		if (e !== void 0 && e !== !0) throw Error("standalone must be true");
		t = e === !0 ? structuredClone(r) : b(t, r);
	}
	let n = t.group_order, r = t.groups;
	if (!Array.isArray(n) || !v(r) || n.some((e) => typeof e != "string") || new Set(n).size !== n.length || n.length !== Object.keys(r).length || n.some((e) => !Object.hasOwn(r, e))) throw Error("Invalid native stylesheet group order");
	for (let e of n) {
		let t = r[e];
		if (!v(t) || !v(t.properties) || !v(t.styles)) throw Error("Invalid native stylesheet group");
		for (let e of x(t.styles, "style")) {
			let n = t.styles[e];
			if (!v(n) || typeof n._type != "string") throw Error("Native stylesheet sample requires a type");
		}
	}
	return t;
}
function C(e) {
	let t = S(e), n = t.groups;
	return t.group_order.flatMap((e) => x(n[e].styles, "style").map((t, r) => {
		let i = n[e].styles[t];
		return {
			group: e,
			slot: t,
			ordinal: r + 1,
			kind: String(i._type),
			sample: i
		};
	}));
}
function w(e, t = 0) {
	if (t > 128) throw Error("Stylesheet sample nesting limit exceeded");
	if (!v(e)) return e;
	let n = {};
	if (typeof e._type == "string" && (n.type = e._type), v(e._attributes)) for (let [t, r] of Object.entries(e._attributes)) y(n, t, r);
	if (e._text !== void 0) return e._text;
	for (let [r, i] of Object.entries(e)) r.startsWith("_") || r.startsWith("$") || y(n, r, r === "row" ? x(i, "row").map((e) => w(i[e], t + 1)) : w(i, t + 1));
	return n;
}
//#endregion
//#region src/palette.ts
var T = (e) => ({
	buttonfield: "ButtonField",
	entryfield: "EntryField",
	togglefield: "ToggleField",
	freetrim: "FreeTrim",
	boxtrim: "BoxTrim",
	radiofield: "RadioField",
	optionfield: "OptionField",
	listfield: "ListField",
	scrollbarfield: "ScrollbarField",
	sliderfield: "SliderField",
	barfield: "BarField",
	rectangleshape: "RectangleShape",
	segmentshape: "SegmentShape",
	ellipseshape: "EllipseShape",
	imagefield: "ImageField",
	imagetrim: "ImageTrim",
	matrixfield: "MatrixField",
	stackfield: "StackField",
	treeviewfield: "TreeviewField",
	subform: "SubForm",
	listviewfield: "ListViewField",
	tabfolder: "TabFolder",
	palettefield: "PaletteField",
	popupbutton: "PopupButton",
	controlbutton: "ControlButton"
})[e] ?? e, E = [
	["Select", "↖"],
	[
		"Button",
		"OK",
		"buttonfield"
	],
	[
		"Entry",
		"ab",
		"entryfield"
	],
	[
		"Multiline entry",
		"a↵",
		"entryfield"
	],
	[
		"Toggle",
		"☒",
		"togglefield"
	],
	[
		"Text",
		"T",
		"freetrim"
	],
	[
		"Boxed text",
		"▣T",
		"boxtrim"
	],
	[
		"Radio",
		"◉",
		"radiofield"
	],
	[
		"Option",
		"▾",
		"optionfield"
	],
	[
		"List",
		"▤",
		"listfield"
	],
	[
		"Scroll bar",
		"↕",
		"scrollbarfield"
	],
	[
		"Slider",
		"⊢",
		"sliderfield"
	],
	[
		"Control button",
		"▦",
		"controlbutton"
	],
	[
		"Bar",
		"▦",
		"barfield"
	],
	[
		"Line",
		"╱",
		"segmentshape"
	],
	[
		"Rectangle",
		"▭",
		"rectangleshape"
	],
	[
		"Ellipse",
		"⬭",
		"ellipseshape"
	],
	[
		"Image",
		"▧",
		"imagefield"
	],
	[
		"Image trim",
		"▨",
		"imagetrim"
	],
	[
		"Palette",
		"⠿",
		"palettefield"
	],
	[
		"Popup button",
		"▱",
		"popupbutton"
	],
	[
		"Tree",
		"⌘",
		"treeviewfield"
	],
	[
		"Tab folder",
		"▰",
		"tabfolder"
	],
	[
		"List view",
		"▥",
		"listviewfield"
	]
], D = /* @__PURE__ */ new Set([
	"entryfield",
	"buttonfield",
	"togglefield",
	"freetrim",
	"boxtrim",
	"ellipseshape",
	"segmentshape",
	"rectangleshape",
	"scrollbarfield",
	"barfield",
	"sliderfield",
	"listfield",
	"optionfield",
	"radiofield",
	"treeviewfield",
	"listviewfield",
	"imagefield",
	"imagetrim",
	"controlbutton",
	"popupbutton",
	"palettefield"
]);
function ee(e, t) {
	let n = C(t);
	return E.map(([e, t, r], i) => {
		let a = {
			id: String(i),
			label: e,
			icon: t,
			className: r ? T(r) : void 0
		};
		if (!r || !D.has(r)) return a;
		let o = n.find((t) => t.kind === r && (e === "Multiline entry" ? t.group === "entryfield:2" : t.group !== "entryfield:2"));
		if (!o) return a;
		let s = o.ordinal;
		try {
			let e = w(o.sample), t = Object.fromEntries(Object.entries(e).filter(([e, t]) => typeof t == "string" && ![
				"type",
				"name",
				"script",
				"row",
				"column"
			].includes(e)));
			if (!Number.isFinite(Number(t.width)) || !Number.isFinite(Number(t.height)) || !t.width || !t.height) return a;
			let n = Object.fromEntries(Object.entries(e).filter(([e, t]) => typeof t == "object" && !!t));
			typeof e.script == "string" && (n.script = e.script), Object.assign(a, {
				kind: r,
				style: s,
				properties: t,
				structured: n
			});
		} catch {}
		return a;
	});
}
//#endregion
//#region src/bitmap.ts
function O(e) {
	if (e.length > 1048576) return;
	let t = 0, n = () => {
		for (; /\s/.test(e[t] ?? "") && t < e.length;) t++;
	}, r = () => {
		n();
		let r = /^-?\d+/.exec(e.slice(t));
		if (!r) throw Error("Missing integer");
		return t += r[0].length, Number(r[0]);
	}, i = (n = !1) => {
		let i = r();
		if (e[t++] !== ":" || i < (n ? -1 : 0) || i > 65536) throw Error("Invalid literal");
		if (i === -1) return "";
		let a = e.slice(t, t + i);
		if (a.length !== i) throw Error("Truncated literal");
		return t += i, a;
	}, a = (r) => {
		let i = "";
		for (let a = 0; a < r; a++) {
			n();
			let r = e[t++];
			if (!r || !/[0-9a-fA-F]/.test(r)) throw Error("Invalid hex");
			i += r;
		}
		return parseInt(i, 16);
	}, o = (r) => {
		if (r === -1) return /* @__PURE__ */ new Uint8Array();
		if (!Number.isInteger(r) || r < 0 || r > 4194304) throw Error("Bitmap too large");
		let i = new Uint8Array(r), o = 0;
		for (; o < r;) {
			n();
			let s = 1;
			if (e[t] === "r") t++, s = a(1) + 3;
			else if (e[t] === "R") {
				t++;
				let e = a(1);
				if (e < 1 || e > 4) throw Error("Invalid run");
				s = 0;
				for (let t = 0; t < e; t++) s += a(2) * 256 ** t;
			}
			let c = a(2);
			if (s < 1 || o + s > r) throw Error("Invalid run length");
			i.fill(c, o, o + s), o += s;
		}
		return i;
	};
	try {
		if (i() !== "bitmapobject") return;
		for (let e = 0; e < 4; e++) r();
		i();
		for (let e = 0; e < 4; e++) r();
		let a = r(), s = r(), c = r(), l = r();
		if (a < 1 || s < 1 || a > 2048 || s > 2048 || a * s > 1048576 || l < 0 || l > 256) return;
		let u = Array.from({ length: l }, () => Array.from({ length: 4 }, r));
		if (u.some((e) => e.some((e) => e < 0 || e > 255))) return;
		let d = o(r());
		for (let e = 0; e < 5; e++) r();
		let f = o(r());
		for (let e = 0; e < 4; e++) r();
		if (i(!0), i(!0), n(), t !== e.length) return;
		let p = c === 12 ? d.length / (a * s) : 0, m = c === 2 ? Math.ceil(a / 8) : a * p;
		if (c === 12 && ![
			1,
			3,
			4
		].includes(p) || ![2, 12].includes(c) || d.length !== m * s) return;
		let h = Math.ceil(a / 8);
		if (f.length && f.length !== h * s) return;
		let g = new Uint8ClampedArray(a * s * 4);
		for (let e = 0; e < s; e++) for (let t = 0; t < a; t++) {
			let n = (e * a + t) * 4;
			if (c === 2) {
				let r = d[e * m + (t >>> 3)] >>> (t & 7) & 1;
				g[n] = g[n + 1] = g[n + 2] = 0, g[n + 3] = r ? 255 : 0;
			} else if (p === 1) {
				let r = u[d[e * m + t]];
				if (!r) return;
				g.set([
					r[2],
					r[1],
					r[0],
					255
				], n);
			} else {
				let r = e * m + t * p;
				g.set([
					d[r + 2],
					d[r + 1],
					d[r],
					p === 4 ? d[r + 3] : 255
				], n);
			}
			f.length && f[e * h + (t >>> 3)] & 128 >>> (t & 7) && (g[n + 3] = 0);
		}
		return {
			width: a,
			height: s,
			rgba: g
		};
	} catch {
		return;
	}
}
//#endregion
//#region src/images.ts
function k(e) {
	return JSON.stringify([
		e.attributes.src?.value,
		e.attributes.mask?.value,
		e.attributes["native-flags"]?.value
	]);
}
function A(e, t = {}) {
	if (!e) return;
	if (e.attributes.src) return t[k(e)];
	let n = e.attributes.obj_encoded?.value;
	return n ? O(n) : void 0;
}
//#endregion
//#region src/choices.ts
var te = (e) => {
	let t = O(e);
	return t ? { bitmap: t } : {};
};
function ne(e, t) {
	let r = e.children.find((e) => e.kind === "colattributes"), i = r ? r.children.filter((e) => e.kind === "row").map((e) => Object.fromEntries(Object.entries(e.attributes).map(([e, t]) => [e, t.value]))) : n(e, t).colattributes?.row ?? [];
	return Array.isArray(i) ? i.slice(0, 100).map((e) => ({
		label: String(e.headertext ?? ""),
		width: Number(e.columnwidth ?? 0)
	})) : [];
}
function j(e, t, r = {}) {
	let i = e.children.find((e) => e.kind === "valuelist");
	if (i) return (i.children.find((e) => e.kind === "choiceitems")?.children ?? []).filter((e) => e.kind === "row").slice(0, 1e4).map((e) => ({
		label: e.attributes.enumdisplay?.value ?? e.attributes.enumtext?.value ?? "",
		value: e.attributes.enumvalue?.value ?? "",
		bitmap: A(e.children.find((e) => e.kind === "enumbitmap"), r)
	}));
	if (Object.hasOwn(e.attributes, "valuelist")) return [];
	let a = n(e, t).valuelist?.choiceitems?.row;
	return Array.isArray(a) ? a.slice(0, 1e4).map((e) => ({
		label: String(e.enumdisplay ?? e.enumtext ?? ""),
		value: String(e.enumvalue ?? ""),
		...te(String(e.enumbitmap?.obj_encoded ?? ""))
	})) : [];
}
//#endregion
//#region src/geometry.ts
var M = 96 / 1e3, N = (e) => Math.round(Math.round(e) / M);
function P(e, t) {
	let n = { ...t };
	for (let [r, i, a] of [[
		"x",
		"xleft",
		"width"
	], [
		"y",
		"ytop",
		"height"
	]]) {
		let o = Number(e[i]), s = t[i] ?? o, c = t[a] === void 0 || Number(e[a]) === 0 ? 1 : t[a] / Number(e[a]);
		for (let t of [1, 2]) {
			let i = `point${t}${r}`;
			e[i] !== void 0 && (n[i] = Math.round(s + (Number(e[i]) - o) * c));
		}
	}
	return n;
}
//#endregion
//#region src/container-layout.ts
function re(e, t, n, r = 18, i = {
	left: 0,
	right: 0,
	top: 0,
	bottom: 0
}, a) {
	if (!Number.isInteger(t) || !Number.isInteger(n) || t < 1 || n < 1 || t > 1e4 || n > 1e4) throw Error("Invalid matrix dimensions");
	if (!Object.values(i).every((e) => Number.isFinite(e) && e >= 0) || a && !Object.values(a).every((e) => Number.isFinite(e) && e >= 0)) throw Error("Invalid container margins or bounds");
	let o = Array(t).fill(0), s = Array(n).fill(0);
	for (let r of e) {
		if (!Number.isInteger(r.row) || !Number.isInteger(r.column) || r.row < 1 || r.row > n || r.column < 1 || r.column > t) throw Error("Matrix cell outside rows/columns");
		if (![r.width, r.height].every((e) => Number.isFinite(e) && e >= 0)) throw Error("Invalid matrix cell size");
		o[r.column - 1] = Math.max(o[r.column - 1], r.width + i.left + i.right), s[r.row - 1] = Math.max(s[r.row - 1], r.height + i.top + i.bottom);
	}
	a && t === 1 && (o[0] = Math.max(o[0], a.width)), a && n === 1 && (s[0] = Math.max(s[0], a.height));
	let c = (e) => {
		let t = 0;
		return e.map((e) => {
			let n = t;
			return t += e, n;
		});
	}, l = c(o), u = c(s), d = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = o[t.column - 1], n = s[t.row - 1], a = t.gravity === void 0 || t.gravity === -1 ? r : t.gravity, c = (a & 7) == 1 ? 0 : (a & 7) == 4 ? 1 : .5, f = (a & 56) == 8 ? 0 : (a & 56) == 32 ? 1 : .5;
		d.set(t.id, {
			x: l[t.column - 1] + i.left + Math.round((e - t.width - i.left - i.right) * c),
			y: u[t.row - 1] + i.top + Math.round((n - t.height - i.top - i.bottom) * f)
		});
	}
	return {
		positions: d,
		width: o.reduce((e, t) => e + t, 0),
		height: s.reduce((e, t) => e + t, 0)
	};
}
function F(e) {
	return [
		"entryfield",
		"buttonfield",
		"boxtrim"
	].includes(e) ? Math.round(2 / M) : e === "imagefield" ? Math.round(6 / M) : 0;
}
//#endregion
//#region src/frame-model.ts
var ie = /* @__PURE__ */ new Set(/* @__PURE__ */ "entryfield.buttonfield.freetrim.boxtrim.stackfield.matrixfield.flexibleform.subform.viewportfield.tablefield.columnfield.listfield.togglefield.optionfield.radiofield.imagefield.imagetrim.segmentshape.barfield.scrollbarfield.sliderfield.treeviewfield.listviewfield.controlbutton.popupbutton.palettefield.tabfolder.ellipseshape.rectangleshape.tabpage.tabbar.tabfield.tablebody.tableheader.titletrim".split("."));
function ae(e, t, n, r = {}) {
	let i = e.root.children.find((e) => e.kind === "topform");
	if (!i) throw Error("Frame has no topform");
	let a = o(i, t), s = (e, t) => {
		if (e === void 0) return 0;
		let n = Number(e);
		if (!e.trim() || !Number.isFinite(n)) throw Error(`Invalid ${t}`);
		return n;
	}, c = [], l = (e) => e && typeof e == "object" && !Array.isArray(e) ? e : {}, u = (e, n, i, a, d, f = 0) => {
		let p = e.kind === "row" && d ? i.type === "tabfield" ? "tabfield" : "tabpage" : e.kind;
		if (!ie.has(p)) {
			if (["tabpagearray", "tabfieldarray"].includes(e.kind) && n) {
				let t = n.kind === "tabfolder" ? n : c.find((e) => e.id === n.parentId), r = l(i).row;
				e.children.filter((e) => e.kind === "row").forEach((i, o) => u(i, n, {
					...l(Array.isArray(r) ? r[o] : void 0),
					type: e.kind === "tabfieldarray" ? "tabfield" : "tabpage"
				}, a, t, o));
			}
			return;
		}
		let m = o({
			...e,
			kind: p === "titletrim" ? "freetrim" : p
		}, t);
		for (let e of ["xleft", "ytop"]) m[e] || (m[e] = {
			value: "0",
			origin: "Native omitted coordinate"
		});
		if ([
			"tabpage",
			"tabfield",
			"tabbar",
			"tablebody",
			"tableheader"
		].includes(p)) for (let t of ["xleft", "ytop"]) e.attributes[t] || (m[t] = {
			value: "0",
			origin: "Native component origin"
		});
		let h = Object.fromEntries(Object.entries(m).map(([e, t]) => [e, t.value])), g = p === "tabpage" && d ? [...a, {
			folderId: d.id,
			index: f
		}] : a, _ = A(e.children.find((e) => [
			"bitmaplabel",
			"bitmap",
			"image",
			"normalbitmap"
		].includes(e.kind)), r), v = A(e.children.find((e) => e.kind === "selectedbitmap"), r), y = {
			id: e.id,
			parentId: n?.id,
			kind: p,
			name: h.name ?? "",
			x: s(h.xleft, `${e.id}.xleft`) * M + (n?.x ?? 0),
			y: s(h.ytop, `${e.id}.ytop`) * M + (n?.y ?? 0),
			width: s(h.width, `${e.id}.width`) * M,
			height: s(h.height, `${e.id}.height`) * M,
			label: h.textlabel ?? h.stringvalue ?? "",
			properties: h,
			propertyOrigins: Object.fromEntries(Object.entries(m).map(([e, t]) => [e, t.origin])),
			source: {
				start: e.start,
				end: e.end
			},
			choices: [
				"listfield",
				"optionfield",
				"radiofield",
				"listviewfield",
				"palettefield"
			].includes(e.kind) ? j(e, t, r) : void 0,
			columns: e.kind === "listviewfield" ? ne(e, t) : void 0,
			pageScopes: g.length ? g : void 0,
			tabTarget: p === "tabfield" && d ? {
				folderId: d.id,
				index: f
			} : void 0,
			backgroundBitmap: A(e.children.find((e) => e.kind === "bgbitmap"), r),
			bitmap: _,
			selectedBitmap: v
		};
		if (y.width < 0 || y.height < 0) throw Error("Negative field dimensions");
		if (c.push(y), p === "columnfield") {
			let n = e.children.find((e) => e.kind === "protofield");
			if (n) {
				let e = Object.keys(n.attributes);
				y.prototype = {
					kind: n.attributes.type?.value ?? (e.some((e) => [
						"charsperline",
						"lines",
						"formatstring",
						"inputmasking"
					].includes(e)) ? "entryfield" : e.some((e) => ["onvalue", "offvalue"].includes(e)) ? "togglefield" : n.children.some((e) => e.kind === "valuelist") ? "optionfield" : e.includes("textlabel") ? "buttonfield" : "unknown"),
					properties: Object.fromEntries(Object.entries(n.attributes).map(([e, t]) => [e, t.value])),
					choices: j(n, t, r)
				};
			}
		}
		let b = {};
		for (let t of e.children) u(t, y, l(b[t.kind]), g);
	};
	for (let e of i.children) u(e, void 0, {}, []);
	let d = /* @__PURE__ */ new Map();
	for (let e of c) if (e.parentId) {
		let t = d.get(e.parentId) ?? [];
		t.push(e), d.set(e.parentId, t);
	}
	let f = (e, t, n) => {
		for (let r of d.get(e) ?? []) r.x += t, r.y += n, f(r.id, t, n);
	};
	for (let e of c.filter((e) => e.kind === "tabbar")) {
		let t = c.find((t) => t.id === e.parentId);
		if (!t) continue;
		let n = e.width + 4;
		e.width = t.width;
		for (let t of d.get(e.id) ?? []) t.kind === "tabfield" && (t.width = n, t.height = e.height, t.properties = {
			...e.properties,
			...t.properties,
			typesize: e.properties.typesize,
			typeface: e.properties.typeface
		});
	}
	for (let e of c.filter((e) => e.kind === "tablebody")) {
		let t = d.get(e.id) ?? [], n = Math.max(0, ...t.map((e) => Number(e.prototype?.properties.height ?? 0) + F(e.prototype?.kind ?? "")));
		for (let e of t) e.prototype && (e.properties = {
			...e.properties,
			visualrowheight: String(n)
		});
	}
	for (let e of c) {
		if (!["stackfield", "matrixfield"].includes(e.kind)) continue;
		let t = d.get(e.id) ?? [];
		if (!t.length) continue;
		let n = e.properties.orientation === "2", r = re(t.map((t, r) => ({
			id: t.id,
			row: e.kind === "matrixfield" ? Number(t.properties.row ?? 1) : n ? 1 : r + 1,
			column: e.kind === "matrixfield" ? Number(t.properties.column ?? 1) : n ? r + 1 : 1,
			width: Number(t.properties.width) + F(t.kind),
			height: Number(t.properties.height) + F(t.kind),
			gravity: Number(t.properties.gravity ?? -1)
		})), e.kind === "matrixfield" ? Number(e.properties.columns) : n ? t.length : 1, e.kind === "matrixfield" ? Number(e.properties.rows) : n ? 1 : t.length, Number(e.properties.childgravity ?? (e.kind === "stackfield" ? 9 : 18)), Object.fromEntries([
			"left",
			"right",
			"top",
			"bottom"
		].map((t) => [t, Math.round(Number(e.properties[`child${t}margin`] ?? 0) * M) / M])), {
			width: e.width / M,
			height: e.height / M
		});
		for (let n of t) {
			let t = r.positions.get(n.id), i = e.x + t.x * M, a = e.y + t.y * M;
			f(n.id, i - n.x, a - n.y), n.x = i, n.y = a, n.properties = {
				...n.properties,
				...n.kind === "segmentshape" ? Object.fromEntries(Object.entries(P(n.properties, {
					xleft: t.x,
					ytop: t.y
				})).map(([e, t]) => [e, String(t)])) : {},
				xleft: String(t.x),
				ytop: String(t.y)
			}, n.propertyOrigins = {
				...n.propertyOrigins,
				xleft: "Native container layout",
				ytop: "Native container layout"
			};
		}
	}
	return {
		uri: e.uri,
		version: e.version,
		title: e.uri.split(/[\\/]/).at(-1) ?? "Frame",
		width: s(n?.attributes.windowwidth?.value ?? a.width?.value, "window.width") * M,
		height: s(n?.attributes.windowheight?.value ?? a.height?.value, "window.height") * M,
		fields: c,
		backgroundBitmap: A(i.children.find((e) => e.kind === "bgbitmap"), r),
		source: e,
		metadata: n,
		formId: i.id,
		formProperties: Object.fromEntries(Object.entries(a).map(([e, t]) => [e, t.value])),
		formOrigins: Object.fromEntries(Object.entries(a).map(([e, t]) => [e, t.origin])),
		palette: ee(e, t),
		defaults: t
	};
}
//#endregion
//#region src/new-frame.ts
var oe = {
	hasscrollbars: "0",
	hasstatusbar: "0",
	isautosized: "0",
	isbordered: "1",
	isclosable: "1",
	ismaximizable: "1",
	ismaximized: "0",
	isminimizable: "1",
	isnullable: "0",
	ispopup: "0",
	isresizeable: "0",
	istitled: "1",
	istoolwindow: "0",
	istopmost: "0",
	curmode: "2",
	windowxleft: "0",
	windowytop: "0"
}, I = {
	freetrim: {
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		exactwidth: "xs:nonNegativeInteger",
		hashorizontalscrollbar: "or_bool",
		tabseqnum: "xs:nonNegativeInteger",
		ismultiline: "or_bool",
		fieldstyle: "xs:nonNegativeInteger",
		innershadowwidth: "xs:integer",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		usewidestcharacter: "xs:nonNegativeInteger",
		exitbehavior: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		stringvalue: "xs:string",
		typesize: "xs:nonNegativeInteger",
		formatstring: "xs:string",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		charsperline: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		ispassword: "or_bool",
		typefacename: "xs:string",
		hasscrollbar: "or_bool",
		clienttext: "xs:string",
		inputmasking: "or_bool",
		nomargins: "or_bool",
		controlfield: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		widestcharacterwidth: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		lines: "xs:nonNegativeInteger",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		forcecase: "xs:integer",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	imagefield: {
		requirerealfield: "or_bool",
		outlinewidth: "xs:integer",
		defaultstring: "xs:string",
		ismandatory: "or_bool",
		mousedowntext: "xs:string",
		designbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		controlfield: "or_bool",
		bgdisplaypolicy: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		clienttext: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		international: "or_bool",
		width: "xs:nonNegativeInteger",
		declared: "or_bool",
		ispropoptinherited: "or_bool",
		ytop: "xs:integer",
		verticaldistribution: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		displaypolicy: "xs:nonNegativeInteger",
		rightinnermargin: "xs:integer",
		isnullable: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		horizontalchildorder: "xs:integer",
		outlinestyle: "xs:integer",
		defaultvalue: "xs:string",
		tabseqnum: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		xleft: "xs:integer",
		datatype: "xs:string",
		height: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		focusbehavior: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinecolor: "xs:nonNegativeInteger",
		bmpdisplaybehavior: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		verticalchildorder: "xs:integer",
		tooltiptext: "xs:string",
		bottominnermargin: "xs:integer",
		name: "or_idname",
		protoname: "or_idname_qual",
		fieldstyle: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		styleclass: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		topinnermargin: "xs:integer",
		cursor: "xs:string"
	},
	ellipseshape: {
		requirerealfield: "or_bool",
		defaultstring: "xs:string",
		mousedowntext: "xs:string",
		designbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		controlfield: "or_bool",
		bgdisplaypolicy: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		clienttext: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		international: "or_bool",
		width: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		verticaldistribution: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		rightinnermargin: "xs:integer",
		isnullable: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		linewidth: "xs:integer",
		user2bias: "xs:nonNegativeInteger",
		horizontalchildorder: "xs:integer",
		defaultvalue: "xs:string",
		readbias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		xleft: "xs:integer",
		datatype: "xs:string",
		height: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		isarray: "or_bool",
		linestyle: "xs:integer",
		leftinnermargin: "xs:integer",
		verticalchildorder: "xs:integer",
		tooltiptext: "xs:string",
		bottominnermargin: "xs:integer",
		name: "or_idname",
		protoname: "or_idname_qual",
		fieldstyle: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		styleclass: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		topinnermargin: "xs:integer",
		cursor: "xs:string"
	},
	frameform: {
		childtopmargin: "xs:integer",
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		verticaldistributiongap: "xs:nonNegativeInteger",
		transparentcolor: "xs:nonNegativeInteger",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		tabseqnum: "xs:nonNegativeInteger",
		fieldstyle: "xs:nonNegativeInteger",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		childbottommargin: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		defaultvalue: "xs:string",
		childgravity: "xs:integer",
		bggradient: "xs:nonNegativeInteger",
		childrightmargin: "xs:integer",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		horizontalchilddistribution: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		typefacename: "xs:string",
		clienttext: "xs:string",
		controlfield: "or_bool",
		horizontaldistributiongap: "xs:nonNegativeInteger",
		childleftmargin: "xs:integer",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		sizetofit: "xs:nonNegativeInteger",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		ismovebounded: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		isresizebounded: "or_bool",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		verticalchilddistribution: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		groupboxlabel: "xs:string",
		user1bias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	sliderfield: {
		style: "xs:integer",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		displayvalues: "or_bool",
		tabseqnum: "xs:nonNegativeInteger",
		fieldstyle: "xs:nonNegativeInteger",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		orientation: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		minvalue: "xs:integer",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		defaultvalue: "xs:string",
		stepsize: "xs:positiveInteger",
		bggradient: "xs:nonNegativeInteger",
		tickintervals: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		pagesize: "xs:positiveInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		user2bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		maxvalue: "xs:integer",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		typefacename: "xs:string",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		typeface: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	framesource: {
		defaultstring: "xs:string",
		istopmost: "or_bool",
		gridlinecolor: "xs:nonNegativeInteger",
		hasscrollbars: "or_bool",
		versshortremarks: "xs:string",
		datatype: "xs:string",
		istoolwindow: "or_bool",
		windowxleft: "xs:integer",
		ismaximized: "or_bool",
		international: "or_bool",
		transparentcolor: "xs:nonNegativeInteger",
		isgridon: "or_bool",
		hasstatusbar: "or_bool",
		curmode: "xs:nonNegativeInteger",
		windowytop: "xs:integer",
		isclosable: "or_bool",
		windowplacement: "xs:string",
		isnullable: "or_bool",
		ismaximizable: "or_bool",
		ispopup: "or_bool",
		defaultvalue: "xs:string",
		windowtitle: "xs:string",
		isresizeable: "or_bool",
		isbordered: "or_bool",
		isminimizable: "or_bool",
		isautosized: "or_bool",
		isarray: "or_bool",
		statustext: "xs:string",
		windowwidth: "xs:nonNegativeInteger",
		windowheight: "xs:nonNegativeInteger",
		templatename: "or_idname_qual",
		gridy: "xs:nonNegativeInteger",
		istitled: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		gridx: "xs:nonNegativeInteger"
	},
	togglefield: {
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		hasindicator: "or_bool",
		tabseqnum: "xs:nonNegativeInteger",
		fieldstyle: "xs:nonNegativeInteger",
		textlabel: "xs:string",
		bottominnermargin: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		imagealignment: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		textdisplaybehavior: "xs:nonNegativeInteger",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		ontextlabel: "xs:string",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		nomargins: "or_bool",
		typefacename: "xs:string",
		isdefaultbutton: "or_bool",
		clienttext: "xs:string",
		controlfield: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		buttonstyle: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		textalignment: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isautosized: "or_bool",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		hasimageandtext: "or_bool",
		bgdisplaypolicy: "xs:integer",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		bmpdisplaybehavior: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	barfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		minvalue: "xs:integer",
		maxvalue: "xs:integer",
		fgpattern: "xs:integer",
		growfrom: "xs:integer"
	},
	treeviewfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		allowlabeledit: "or_bool",
		hasbuttons: "or_bool",
		haslines: "or_bool",
		hasrootline: "or_bool",
		showselection: "or_bool",
		typeface: "xs:integer",
		typesize: "xs:nonNegativeInteger",
		isbold: "or_bool",
		isitalic: "or_bool",
		typefacename: "xs:string",
		isunderlined: "or_bool",
		style: "xs:nonNegativeInteger",
		rightclickbehavior: "xs:nonNegativeInteger",
		fullrowselect: "or_bool",
		hascheckboxes: "or_bool",
		indent: "xs:nonNegativeInteger",
		selbgcolor: "xs:nonNegativeInteger",
		selfgcolor: "xs:nonNegativeInteger",
		selnofocusbgcolor: "xs:nonNegativeInteger",
		selnofocusfgcolor: "xs:nonNegativeInteger",
		hasscrollbar: "or_bool",
		hashorizontalscrollbar: "or_bool",
		exactnodeheight: "xs:nonNegativeInteger",
		labelbias: "xs:nonNegativeInteger"
	},
	imagetrim: {
		requirerealfield: "or_bool",
		outlinewidth: "xs:integer",
		defaultstring: "xs:string",
		ismandatory: "or_bool",
		mousedowntext: "xs:string",
		designbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		controlfield: "or_bool",
		bgdisplaypolicy: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		clienttext: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		international: "or_bool",
		width: "xs:nonNegativeInteger",
		declared: "or_bool",
		ispropoptinherited: "or_bool",
		ytop: "xs:integer",
		verticaldistribution: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		displaypolicy: "xs:nonNegativeInteger",
		rightinnermargin: "xs:integer",
		isnullable: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		horizontalchildorder: "xs:integer",
		outlinestyle: "xs:integer",
		defaultvalue: "xs:string",
		tabseqnum: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		xleft: "xs:integer",
		datatype: "xs:string",
		height: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		focusbehavior: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinecolor: "xs:nonNegativeInteger",
		bmpdisplaybehavior: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		verticalchildorder: "xs:integer",
		tooltiptext: "xs:string",
		bottominnermargin: "xs:integer",
		name: "or_idname",
		protoname: "or_idname_qual",
		fieldstyle: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		styleclass: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		topinnermargin: "xs:integer",
		cursor: "xs:string"
	},
	listviewfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		curenumindex: "xs:nonNegativeInteger",
		typeface: "xs:integer",
		typesize: "xs:nonNegativeInteger",
		isbold: "or_bool",
		isitalic: "or_bool",
		typefacename: "xs:string",
		isunderlined: "or_bool",
		exactwidth: "xs:nonNegativeInteger",
		minimumwidth: "xs:nonNegativeInteger",
		dragitem: "or_bool",
		editlabel: "or_bool",
		fullrowselect: "or_bool",
		hascolumnheaders: "or_bool",
		style: "xs:nonNegativeInteger",
		largeimageheight: "xs:nonNegativeInteger",
		largeimagewidth: "xs:nonNegativeInteger",
		smallimageheight: "xs:nonNegativeInteger",
		smallimagewidth: "xs:nonNegativeInteger"
	},
	entryfield: {
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		exactwidth: "xs:nonNegativeInteger",
		hashorizontalscrollbar: "or_bool",
		tabseqnum: "xs:nonNegativeInteger",
		ismultiline: "or_bool",
		fieldstyle: "xs:nonNegativeInteger",
		innershadowwidth: "xs:integer",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		usewidestcharacter: "xs:nonNegativeInteger",
		exitbehavior: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		formatstring: "xs:string",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		charsperline: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		ispassword: "or_bool",
		typefacename: "xs:string",
		hasscrollbar: "or_bool",
		clienttext: "xs:string",
		inputmasking: "or_bool",
		nomargins: "or_bool",
		controlfield: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		widestcharacterwidth: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		lines: "xs:nonNegativeInteger",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		forcecase: "xs:integer",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	boxtrim: {
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		exactwidth: "xs:nonNegativeInteger",
		hashorizontalscrollbar: "or_bool",
		tabseqnum: "xs:nonNegativeInteger",
		ismultiline: "or_bool",
		fieldstyle: "xs:nonNegativeInteger",
		innershadowwidth: "xs:integer",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		usewidestcharacter: "xs:nonNegativeInteger",
		exitbehavior: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		stringvalue: "xs:string",
		typesize: "xs:nonNegativeInteger",
		formatstring: "xs:string",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		charsperline: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		ispassword: "or_bool",
		typefacename: "xs:string",
		hasscrollbar: "or_bool",
		clienttext: "xs:string",
		inputmasking: "or_bool",
		nomargins: "or_bool",
		controlfield: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		widestcharacterwidth: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		lines: "xs:nonNegativeInteger",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		forcecase: "xs:integer",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	optionfield: {
		minimumwidth: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		curenumindex: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		exactwidth: "xs:nonNegativeInteger",
		tabseqnum: "xs:nonNegativeInteger",
		fieldstyle: "xs:nonNegativeInteger",
		innershadowwidth: "xs:integer",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		textlabel: "xs:string",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		typefacename: "xs:string",
		clienttext: "xs:string",
		controlfield: "or_bool",
		visiblerows: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		style: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	listfield: {
		minimumwidth: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		curenumindex: "xs:nonNegativeInteger",
		isunderlined: "or_bool",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		exactwidth: "xs:nonNegativeInteger",
		hassinglecharfind: "or_bool",
		fieldstyle: "xs:nonNegativeInteger",
		innershadowwidth: "xs:integer",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		mousedowntext: "xs:string",
		selectiontype: "xs:nonNegativeInteger",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		typefacename: "xs:string",
		clienttext: "xs:string",
		controlfield: "or_bool",
		visiblerows: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		tooltiptext: "xs:string",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	buttonfield: {
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		tabseqnum: "xs:nonNegativeInteger",
		fieldstyle: "xs:nonNegativeInteger",
		textlabel: "xs:string",
		bottominnermargin: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		imagealignment: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		textdisplaybehavior: "xs:nonNegativeInteger",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		nomargins: "or_bool",
		typefacename: "xs:string",
		isdefaultbutton: "or_bool",
		clienttext: "xs:string",
		controlfield: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		buttonstyle: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		textalignment: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isautosized: "or_bool",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		bmpdisplaybehavior: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	radiofield: {
		minimumwidth: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		verticalchildorder: "xs:integer",
		isnullable: "or_bool",
		xleft: "xs:integer",
		fgcolor: "xs:nonNegativeInteger",
		curenumindex: "xs:nonNegativeInteger",
		protoname: "or_idname_qual",
		defaultstring: "xs:string",
		exactwidth: "xs:nonNegativeInteger",
		tabseqnum: "xs:nonNegativeInteger",
		fieldstyle: "xs:nonNegativeInteger",
		columns: "xs:nonNegativeInteger",
		bgdisplaypolicy: "xs:integer",
		bottominnermargin: "xs:integer",
		orientation: "xs:integer",
		mousedowntext: "xs:string",
		horizontaldistribution: "xs:nonNegativeInteger",
		name: "or_idname",
		anchorpoint: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		typesize: "xs:nonNegativeInteger",
		defaultvalue: "xs:string",
		bggradient: "xs:nonNegativeInteger",
		columnheightcompressed: "or_bool",
		mousemovetext: "xs:string",
		declared: "or_bool",
		isbold: "or_bool",
		trimbias: "xs:nonNegativeInteger",
		requirerealfield: "or_bool",
		topinnermargin: "xs:integer",
		outlinecolor: "xs:nonNegativeInteger",
		ytop: "xs:integer",
		typeface: "xs:integer",
		isreverse: "or_bool",
		rightinnermargin: "xs:integer",
		styleclass: "xs:nonNegativeInteger",
		width: "xs:nonNegativeInteger",
		cursor: "xs:string",
		designbias: "xs:nonNegativeInteger",
		typefacename: "xs:string",
		clienttext: "xs:string",
		controlfield: "or_bool",
		updatebias: "xs:nonNegativeInteger",
		ispropoptinherited: "or_bool",
		horizontalchildorder: "xs:integer",
		isitalic: "or_bool",
		height: "xs:nonNegativeInteger",
		focusbehavior: "xs:nonNegativeInteger",
		international: "or_bool",
		bgpattern: "xs:integer",
		outlinewidth: "xs:integer",
		isunderlined: "or_bool",
		tooltiptext: "xs:string",
		columnwidthcompressed: "or_bool",
		leftinnermargin: "xs:integer",
		ismandatory: "or_bool",
		datatype: "xs:string",
		readbias: "xs:nonNegativeInteger",
		gravity: "xs:integer",
		user1bias: "xs:nonNegativeInteger",
		bgcolor: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		isarray: "or_bool",
		outlinestyle: "xs:integer",
		user3bias: "xs:nonNegativeInteger"
	},
	rectangleshape: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		linestyle: "xs:integer",
		linewidth: "xs:integer"
	},
	segmentshape: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		linestyle: "xs:integer",
		linewidth: "xs:integer",
		point1x: "xs:integer",
		point1y: "xs:integer",
		point2x: "xs:integer",
		point2y: "xs:integer"
	},
	scrollbarfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		minvalue: "xs:integer",
		maxvalue: "xs:integer",
		elevatorsize: "xs:positiveInteger",
		orientation: "xs:integer",
		pagesize: "xs:positiveInteger",
		stepsize: "xs:positiveInteger"
	},
	stackfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool",
		orientation: "xs:integer",
		childgravity: "xs:integer",
		childbottommargin: "xs:integer",
		childleftmargin: "xs:integer",
		childrightmargin: "xs:integer",
		childtopmargin: "xs:integer",
		separatorcolor: "xs:nonNegativeInteger",
		separatorstyle: "xs:integer",
		separatorwidth: "xs:integer",
		separatormoving: "xs:nonNegativeInteger"
	},
	matrixfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool",
		collapsepolicy: "xs:integer",
		columns: "xs:integer",
		rows: "xs:integer",
		childgravity: "xs:integer",
		childbottommargin: "xs:integer",
		childleftmargin: "xs:integer",
		childrightmargin: "xs:integer",
		childtopmargin: "xs:integer",
		separatorstyle: "xs:integer",
		separatorwidth: "xs:integer"
	},
	flexibleform: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool"
	},
	subform: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool",
		childgravity: "xs:integer",
		horizontalchilddistribution: "xs:nonNegativeInteger",
		verticalchilddistribution: "xs:nonNegativeInteger",
		horizontaldistributiongap: "xs:nonNegativeInteger",
		verticaldistributiongap: "xs:nonNegativeInteger",
		groupboxlabel: "xs:string",
		sizetofit: "xs:nonNegativeInteger",
		typeface: "xs:integer",
		typesize: "xs:nonNegativeInteger",
		isbold: "or_bool",
		isitalic: "or_bool",
		typefacename: "xs:string",
		isunderlined: "or_bool",
		childbottommargin: "xs:integer",
		childleftmargin: "xs:integer",
		childrightmargin: "xs:integer",
		childtopmargin: "xs:integer"
	},
	viewportfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool",
		innershadowwidth: "xs:integer",
		hidehorizontalscrollbar: "or_bool",
		xoffset: "xs:nonNegativeInteger",
		yoffset: "xs:nonNegativeInteger"
	},
	tablefield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool",
		alwayshighlighted: "or_bool",
		colseparatorcolor: "xs:nonNegativeInteger",
		colseparatorstyle: "xs:integer",
		colseparatorwidth: "xs:integer",
		rowseparatorcolor: "xs:nonNegativeInteger",
		rowseparatorstyle: "xs:integer",
		rowseparatorwidth: "xs:integer",
		columnresizable: "or_bool",
		columnsdisplayed: "xs:positiveInteger",
		hasheader: "or_bool",
		hasheaderbuttons: "or_bool",
		hashorizontalscrollbar: "or_bool",
		hasscrollbar: "or_bool",
		ishighlighted: "or_bool",
		numvisiblerows: "xs:positiveInteger",
		orientation: "xs:integer",
		designops: "xs:nonNegativeInteger",
		trimops: "xs:nonNegativeInteger",
		updateops: "xs:nonNegativeInteger",
		queryops: "xs:nonNegativeInteger",
		readops: "xs:nonNegativeInteger",
		user1ops: "xs:nonNegativeInteger",
		user2ops: "xs:nonNegativeInteger",
		user3ops: "xs:nonNegativeInteger",
		scrollingchangesselection: "or_bool",
		selectiontype: "xs:nonNegativeInteger",
		exactwidth: "xs:nonNegativeInteger",
		exactheight: "xs:nonNegativeInteger"
	},
	columnfield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool",
		orientation: "xs:integer",
		childgravity: "xs:integer",
		childbottommargin: "xs:integer",
		childleftmargin: "xs:integer",
		childrightmargin: "xs:integer",
		childtopmargin: "xs:integer",
		separatorcolor: "xs:nonNegativeInteger",
		separatorstyle: "xs:integer",
		separatorwidth: "xs:integer",
		separatormoving: "xs:nonNegativeInteger",
		hascellattributes: "or_bool",
		hassinglecharfind: "or_bool",
		isextracolumn: "or_bool"
	},
	controlbutton: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		typeface: "xs:integer",
		typesize: "xs:nonNegativeInteger",
		isbold: "or_bool",
		isitalic: "or_bool",
		typefacename: "xs:string",
		isunderlined: "or_bool",
		textlabel: "xs:string",
		textdisplaybehavior: "xs:nonNegativeInteger",
		textalignment: "xs:nonNegativeInteger",
		buttonstyle: "xs:nonNegativeInteger",
		bmpdisplaybehavior: "xs:nonNegativeInteger",
		imagealignment: "xs:nonNegativeInteger",
		isautosized: "or_bool",
		nomargins: "or_bool",
		isdefaultbutton: "or_bool",
		popupalignment: "xs:nonNegativeInteger"
	},
	popupbutton: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		typeface: "xs:integer",
		typesize: "xs:nonNegativeInteger",
		isbold: "or_bool",
		isitalic: "or_bool",
		typefacename: "xs:string",
		isunderlined: "or_bool",
		textlabel: "xs:string",
		textdisplaybehavior: "xs:nonNegativeInteger",
		textalignment: "xs:nonNegativeInteger",
		buttonstyle: "xs:nonNegativeInteger",
		bmpdisplaybehavior: "xs:nonNegativeInteger",
		imagealignment: "xs:nonNegativeInteger",
		isautosized: "or_bool",
		nomargins: "or_bool",
		isdefaultbutton: "or_bool",
		popupalignment: "xs:nonNegativeInteger"
	},
	palettefield: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		curenumindex: "xs:nonNegativeInteger",
		bmpdisplaybehavior: "xs:nonNegativeInteger",
		buttonstyle: "xs:nonNegativeInteger",
		orientation: "xs:integer",
		columns: "xs:nonNegativeInteger",
		innershadowwidth: "xs:integer"
	},
	tabfolder: {
		name: "or_idname",
		datatype: "xs:string",
		isarray: "or_bool",
		isnullable: "or_bool",
		defaultvalue: "xs:string",
		defaultstring: "xs:string",
		bgcolor: "xs:nonNegativeInteger",
		fgcolor: "xs:nonNegativeInteger",
		clienttext: "xs:string",
		controlfield: "or_bool",
		protoname: "or_idname_qual",
		international: "or_bool",
		styleclass: "xs:nonNegativeInteger",
		leftinnermargin: "xs:integer",
		rightinnermargin: "xs:integer",
		topinnermargin: "xs:integer",
		bottominnermargin: "xs:integer",
		xleft: "xs:integer",
		ytop: "xs:integer",
		width: "xs:nonNegativeInteger",
		height: "xs:nonNegativeInteger",
		designbias: "xs:nonNegativeInteger",
		trimbias: "xs:nonNegativeInteger",
		updatebias: "xs:nonNegativeInteger",
		querybias: "xs:nonNegativeInteger",
		readbias: "xs:nonNegativeInteger",
		user1bias: "xs:nonNegativeInteger",
		user2bias: "xs:nonNegativeInteger",
		user3bias: "xs:nonNegativeInteger",
		isreverse: "or_bool",
		gravity: "xs:integer",
		horizontaldistribution: "xs:nonNegativeInteger",
		verticaldistribution: "xs:nonNegativeInteger",
		anchorpoint: "xs:nonNegativeInteger",
		genfield: "or_bool",
		horizontalchildorder: "xs:integer",
		verticalchildorder: "xs:integer",
		requirerealfield: "or_bool",
		cursor: "xs:string",
		tooltiptext: "xs:string",
		fieldstyle: "xs:nonNegativeInteger",
		bggradient: "xs:nonNegativeInteger",
		bgpattern: "xs:integer",
		mousedowntext: "xs:string",
		mousemovetext: "xs:string",
		bgdisplaypolicy: "xs:integer",
		declared: "or_bool",
		focusbehavior: "xs:nonNegativeInteger",
		outlinecolor: "xs:nonNegativeInteger",
		outlinestyle: "xs:integer",
		outlinewidth: "xs:integer",
		tabseqnum: "xs:nonNegativeInteger",
		ismandatory: "or_bool",
		ispropoptinherited: "or_bool",
		ismovebounded: "or_bool",
		isresizebounded: "or_bool",
		isshadowed: "or_bool"
	}
}, L = "AbsXLeft AbsXRight AbsYBottom AbsYTop AllBias AnchorPoint BgBitmap BgColor BgDisplayPolicy BgPattern ClientText ControlField Cursor DataType Declared DefaultString DefaultValue FgColor Field_Template FocusBehavior Gravity Height IsBold IsItalic IsNullable IsPlain IsPropOptInherited IsReverse LayerSequence MouseDownText MouseMoveText Name OuterHeight OuterWidth OutlineColor OutlineStyle OutlineWidth QueryBias ReadBias RequireRealField TabSeqNum TaggedValues TextAlignment TextDisplayBehavior ToolTipText TypeFace TypeFaceName TypeSize UpdateBias User1Bias User2Bias User3Bias Width XAnchorPoint XLeft XRight YAnchorPoint YBottom YTop", R = L + " BitmapLabel BmpDisplayBehavior ButtonStyle DefaultButton IsAutoSized TextLabel", z = L.replace(" TextAlignment TextDisplayBehavior", "") + " BottomInnerMargin CharsPerLine ExactWidth ForceCase FormatString InputMasking IsMandatory IsMultiLine IsPassword LeftInnerMargin Lines MaxCharacters RightInnerMargin TopInnerMargin UseWidestCharacter WidestCharacterWidth", se = L.split(" ").filter((e) => ![
	"DataType",
	"DefaultString",
	"DefaultValue",
	"IsBold",
	"IsItalic",
	"IsPlain",
	"TextAlignment",
	"TextDisplayBehavior",
	"TypeFace",
	"TypeFaceName",
	"TypeSize"
].includes(e)).join(" ") + " BmpDisplayBehavior DisplayPolicy", B = "BgBitmap BgColor BgPattern CurMode DataType HasScrollBars HasStatusBar IsAutoSized IsBordered IsClosable IsMaximizable IsMaximized IsMinimizable IsNullable IsPopup IsResizeable IsTitled IsToolWindow IsTopmost SetupName StatusText TaggedValues TemplateName TransparentColor VersShortRemarks WindowHeight WindowIcon WindowPlacement WindowTitle WindowWidth WindowLeft WindowTop".split(" "), V = new Map([
	...R.split(" "),
	...z.split(" "),
	...B,
	..."DesignBias TrimBias DisplayPolicy BgGradient HorizontalDistribution VerticalDistribution HorizontalChildOrder VerticalChildOrder IsArray International FieldStyle StyleClass IsMandatory LineWidth LineStyle Protoname ImageWidth ImageHeight Bitmap ImagePosition HasScrollBars HasColumnHeaders HasLines HasButtons IsExpanded RootNode IndentWidth FullRowSelect LargeImageWidth LargeImageHeight SmallImageWidth SmallImageHeight MinimumWidth CurEnumIndex ExactWidth EditLabel SelectionStyle Orientation MinValue MaxValue Increment PageIncrement Value SliderSize ShowValue IsReadOnly IsEditable EnumList ValueList Columns Rows ChildFields TabFolderStyle TabLocation TabWidth TabHeight CurPage MinimumHeight BorderStyle SelectionPolicy AllowSelect".split(" ")
].map((e) => [e.replace("_", "").toLowerCase(), e.replace("_", " ")]));
for (let e of "AllowLabelEdit AlwaysHighlighted ChildBottomMargin ChildGravity ChildLeftMargin ChildRightMargin ChildTopMargin CollapsePolicy ColSeparatorColor ColSeparatorStyle ColSeparatorWidth ColumnHeightCompressed ColumnResizable Columns ColumnsDisplayed ColumnWidthCompressed DesignOps DisplayValues DragItem ElevatorSize ExactHeight ExactNodeHeight ExitBehavior FgPattern GenField GridLineColor GridX GridY GroupBoxLabel GrowFrom HasCellAttributes HasCheckBoxes HasHeader HasHeaderButtons HasHorizontalScrollBar HasImageAndText HasIndicator HasRootLine HasScrollBar HasSingleCharFind HideHorizontalScrollBar HorizontalChildDistribution HorizontalDistributionGap ImageAlignment Indent InnerShadowWidth IsExtraColumn IsGridOn IsHighlighted IsMoveBounded IsResizeBounded IsShadowed IsUnderlined LabelBias NoMargins NumVisibleRows OnTextLabel PageSize Point1X Point1Y Point2X Point2Y PopupAlignment QueryOps ReadOps RightClickBehavior RowSeparatorColor RowSeparatorStyle RowSeparatorWidth ScrollingChangesSelection SelBgColor SelectionType SelFgColor SelNoFocusBgColor SelNoFocusFgColor SeparatorColor SeparatorMoving SeparatorStyle SeparatorWidth ShowSelection SizeToFit StepSize StringValue Style TickIntervals TrimOps UpdateOps User1Ops User2Ops User3Ops VerticalChildDistribution VerticalDistributionGap VisibleRows WindowXLeft WindowYTop XOffset YOffset".split(" ")) V.set(e.toLowerCase(), e);
function H(e) {
	return V.get(e) ?? e;
}
function ce(e, t) {
	let n = e === "buttonfield" ? R : e === "entryfield" ? z : ["imagefield", "imagetrim"].includes(e) ? se + (e === "imagetrim" ? " Image" : "") : "";
	return [...new Set(n ? n.split(" ").map((e) => e.replace("_", " ")) : [...Object.keys(t).filter((e) => e !== "gorak_style").map(H), ...Object.keys(I[e] ?? {}).map(H)])].sort((e, t) => e.toLowerCase().localeCompare(t.toLowerCase()));
}
var le = (e) => ({
	WindowLeft: "windowxleft",
	WindowTop: "windowytop"
})[e] ?? e.toLowerCase(), ue = (e) => e === "DefaultButton" ? "isdefaultbutton" : e.replaceAll(" ", "").toLowerCase(), U = {
	1: "CC_FOREGROUND",
	2: "CC_BACKGROUND",
	4: "CC_BLACK",
	5: "CC_WHITE",
	6: "CC_RED",
	7: "CC_GREEN",
	8: "CC_BLUE",
	9: "CC_YELLOW",
	10: "CC_CYAN",
	11: "CC_MAGENTA",
	12: "CC_BROWN",
	13: "CC_ORANGE",
	14: "CC_PURPLE",
	15: "CC_GRAY",
	70: "CC_SYS_BTNFACE",
	71: "CC_SYS_BTNSHADOW",
	72: "CC_SYS_BTNTEXT",
	75: "CC_SYS_HIGHLIGHT",
	76: "CC_SYS_HIGHLIGHTTEXT",
	84: "CC_SYS_WINDOW",
	86: "CC_SYS_WINDOWTEXT",
	91: "CC_TRANSPARENT"
}, W = {
	displaypolicy: {
		1: "DP_CLIP_IMAGE",
		2: "DP_AUTOSIZE_FIELD",
		3: "DP_SCALE_IMAGE_H",
		4: "DP_SCALE_IMAGE_W",
		5: "DP_SCALE_IMAGE_HW"
	},
	bmpdisplaybehavior: {
		0: "BDB_OPAQUE",
		1: "BDB_TRANSPARENT",
		2: "BDB_3DMAPPED"
	},
	collapsepolicy: {
		0: "CP_NONE",
		1: "CP_ROWS",
		2: "CP_COLUMNS",
		3: "CP_BOTH"
	},
	orientation: {
		"-1": "FO_DEFAULT",
		1: "FO_VERTICAL",
		2: "FO_HORIZONTAL"
	},
	bgcolor: U,
	fgcolor: U,
	outlinecolor: U,
	transparentcolor: U,
	anchorpoint: {
		0: "AP_NONE",
		9: "AP_TOPLEFT",
		10: "AP_TOPCENTER",
		12: "AP_TOPRIGHT",
		17: "AP_CENTERLEFT",
		18: "AP_CENTER",
		20: "AP_CENTERRIGHT",
		33: "AP_BOTTOMLEFT",
		34: "AP_BOTTOMCENTER",
		36: "AP_BOTTOMRIGHT"
	},
	focusbehavior: {
		1: "FT_NOSETVALUE",
		2: "FT_SETVALUE",
		3: "FT_TAKEFOCUS",
		4: "FT_TABTO"
	},
	bgpattern: {
		"-1": "FP_DEFAULT",
		1: "FP_SOLID",
		2: "FP_CLEAR",
		3: "FP_HORIZONTAL",
		4: "FP_VERTICAL",
		5: "FP_CROSSHATCH",
		6: "FP_SHADE",
		7: "FP_LIGHTSHADE",
		8: "FP_DARKSHADE",
		9: "FP_BITMAP",
		11: "FP_BITMAPCLEAR"
	},
	bgdisplaypolicy: {
		"-1": "BDP_DEFAULT",
		1: "BDP_FIXED",
		2: "BDP_RELATIVE"
	},
	outlinestyle: {
		"-1": "OS_DEFAULT",
		1: "OS_SOLID",
		2: "OS_SHADOW",
		3: "OS_3D",
		4: "OS_STANDARD",
		5: "OS_RAISED",
		6: "OS_SUNKEN"
	},
	outlinewidth: {
		"-1": "LW_DEFAULT",
		0: "LW_NOLINE",
		1: "LW_MINIMUM",
		2: "LW_VERYTHIN",
		3: "LW_THIN",
		4: "LW_MIDDLE",
		5: "LW_THICK",
		6: "LW_MAXIMUM",
		7: "LW_EXTRATHIN"
	},
	forcecase: {
		1: "FC_NONE",
		2: "FC_UPPER",
		3: "FC_LOWER"
	},
	curmode: {
		2: "FM_UPDATE",
		3: "FM_QUERY",
		4: "FM_READ",
		5: "FM_USER1",
		6: "FM_USER2",
		7: "FM_USER3"
	},
	defaultvalue: {
		1: "DV_SYSTEM",
		2: "DV_NULL",
		3: "DV_STRING"
	},
	gravity: {
		"-1": "FA_DEFAULT",
		0: "FA_NONE",
		9: "FA_TOPLEFT",
		10: "FA_TOPCENTER",
		12: "FA_TOPRIGHT",
		17: "FA_CENTERLEFT",
		18: "FA_CENTER",
		20: "FA_CENTERRIGHT",
		33: "FA_BOTTOMLEFT",
		34: "FA_BOTTOMCENTER",
		36: "FA_BOTTOMRIGHT"
	}
};
W.childgravity = W.gravity;
function G(e, t, n) {
	return I[e]?.[t] === "or_bool" || /^is|^has/.test(t) && ["0", "1"].includes(n) ? n === "1" ? "TRUE" : n === "0" ? "FALSE" : n : W[t]?.[n] ?? n;
}
function de(e, t, n) {
	let r = I[e]?.[t];
	if (r === "or_bool" && !["0", "1"].includes(n)) throw Error("Choose TRUE or FALSE");
	if ((r?.includes("Integer") || r === "xs:integer") && (!/^-?\d+$/.test(n) || !Number.isSafeInteger(Number(n)) || Math.abs(Number(n)) > 1e6 || r.includes("nonNegative") && Number(n) < 0)) throw Error("Expected an integer in the supported range");
	if ([
		"width",
		"height",
		"windowwidth",
		"windowheight"
	].includes(t) && (!/^\d+$/.test(n) || Number(n) < 1 || Number(n) > 1e6)) throw Error("Size must be between 1 and 1,000,000");
	if (["or_idname", "or_idname_qual"].includes(r) && !/^[A-Za-z_][\w.]*$/.test(n)) throw Error("Invalid field name");
}
//#endregion
//#region src/appearance.ts
var K = {
	1: "#000000",
	2: "#ffffff",
	4: "#000000",
	5: "#ffffff",
	6: "#800000",
	7: "#008000",
	8: "#000080",
	9: "#808000",
	10: "#008080",
	11: "#800080",
	12: "#400000",
	13: "#c04000",
	14: "#4000c0",
	15: "#808080",
	16: "#ff0000",
	17: "#00ff00",
	18: "#0000ff",
	19: "#ffff00",
	20: "#00ffff",
	21: "#ff00ff",
	22: "#804000",
	23: "#ff8000",
	24: "#8000ff",
	25: "#a0a0a4",
	26: "#ff8080",
	27: "#c0dcc0",
	28: "#a6caf0",
	29: "#ffff80",
	30: "#80ffff",
	31: "#ff80ff",
	32: "#dfa060",
	33: "#ff8020",
	34: "#c082ff",
	35: "#c0c0c0",
	70: "#f0f0f0",
	71: "#808080",
	72: "#000000",
	73: "#ffffff",
	74: "#6d6d6d",
	75: "#0078d7",
	76: "#ffffff",
	84: "#ffffff",
	86: "#000000",
	83: "#ffffff",
	87: "#696969",
	88: "#e3e3e3",
	89: "#000000",
	90: "#ffffe1",
	91: "transparent"
};
function q(e) {
	if (e === void 0) return;
	if (K[e]) return K[e];
	let t = Number(e);
	if (!(!Number.isInteger(t) || t < 16777216 || t > 33554431)) return "#" + [
		t & 255,
		t >>> 8 & 255,
		t >>> 16 & 255
	].map((e) => e.toString(16).padStart(2, "0")).join("");
}
function J(e, t) {
	let n = q(t.bgcolor), r = q(t.fgcolor), i = q(t.outlinecolor);
	n && (e.style.backgroundColor = n), r && (e.style.color = r), i && (e.style.borderColor = i), ["2", "11"].includes(t.bgpattern ?? "") && (e.style.backgroundColor = "transparent"), t.outlinewidth === "0" && (e.style.borderWidth = "0"), t.typesize && Number(t.typesize) > 0 && (e.style.fontSize = `${Number(t.typesize) * 96 / 72}px`);
	let a = {
		0: "Tahoma, Arial, sans-serif",
		1: "Arial, Helvetica, sans-serif",
		2: "\"Courier New\", monospace",
		3: "\"Times New Roman\", serif",
		4: "\"Century Schoolbook\", serif",
		5: "\"Lucida Sans\", sans-serif"
	};
	a[t.typeface] && (e.style.fontFamily = a[t.typeface]), t.typeface === "-9" && t.typefacename && (e.style.fontFamily = JSON.stringify(t.typefacename)), t.isbold === "1" && (e.style.fontWeight = "bold"), t.isitalic === "1" && (e.style.fontStyle = "italic"), t.ismultiline === "1" && (e.style.whiteSpace = "pre-wrap");
}
//#endregion
//#region src/grouping.ts
function Y(e, t, n, r, i) {
	let a = {
		xleft: Math.round(r),
		ytop: Math.round(i)
	};
	if (t.kind === "segmentshape") {
		let e = {
			...Object.fromEntries(Object.entries(t.attributes).map(([e, t]) => [e, t.value])),
			...n.properties
		};
		for (let [t, o, s] of [[
			"x",
			n.x,
			r
		], [
			"y",
			n.y,
			i
		]]) for (let n of [1, 2]) {
			let r = `point${n}${t}`, i = Number(e[r]);
			if (e[r] === void 0 || !Number.isFinite(i)) throw Error("Segment endpoints require authoritative defaults");
			a[r] = Math.round(i + s - o);
		}
	}
	return Object.entries(a).flatMap(([n, r]) => s(e, t.id, n, String(r)).edits);
}
function fe(e, t, n, r = 1) {
	let i = e.nodes.find((e) => e.id === t);
	if (i?.kind !== "stackfield") throw Error("Select a stack field child");
	let a = new Set(n.map((e) => e.id));
	if (a.size !== n.length || i.children.length !== n.length || i.children.some((e) => !a.has(e.id))) throw Error("Stack contains unsupported child source");
	if (n.some((e) => ![e.width, e.height].every((e) => Number.isFinite(e) && e >= 0))) throw Error("Invalid stack dimensions");
	let o = 0, s = n.map((t) => {
		let n = i.children.find((e) => e.id === t.id), a = e.text.slice(n.start, n.end), s = Y(e, n, t, r === 2 ? o : 0, r === 2 ? 0 : o);
		o += r === 2 ? t.width : t.height;
		for (let e of s.sort((e, t) => t.start - e.start)) a = a.slice(0, e.start - n.start) + e.text + a.slice(e.end - n.start);
		return a;
	});
	return {
		uri: e.uri,
		version: e.version,
		edits: i.children.map((t, n) => ({
			start: t.start,
			end: t.end,
			expected: e.text.slice(t.start, t.end),
			text: s[n]
		}))
	};
}
function pe(e, t, n, r, i = 1) {
	let a = d(e, t.map((e) => e.id)).sort((e, r) => n === "stackfield" ? t.find((t) => t.id === e.id).y - t.find((e) => e.id === r.id).y || t.find((t) => t.id === e.id).x - t.find((e) => e.id === r.id).x : e.start - r.start);
	if (a.length < 2) throw Error("Select at least two sibling fields");
	if (a.some((e) => e.parentId !== a[0].parentId)) throw Error("Group fields with the same parent");
	let o = a.map((e) => t.find((t) => t.id === e.id));
	if (o.some((e) => !e || ![
		e.x,
		e.y,
		e.width,
		e.height
	].every(Number.isFinite))) throw Error("Invalid group geometry");
	let s = Math.min(...o.map((e) => e.x)), c = Math.min(...o.map((e) => e.y)), l = n === "stackfield" ? i === 2 ? o.reduce((e, t) => e + t.width, 0) : Math.max(...o.map((e) => e.width)) : Math.max(...o.map((e) => e.x + e.width)) - s, u = n === "stackfield" ? i === 2 ? Math.max(...o.map((e) => e.height)) : o.reduce((e, t) => e + t.height, 0) : Math.max(...o.map((e) => e.y + e.height)) - c, f = 0, p = new Set(e.nodes.map((e) => e.attributes.name?.value)), m = 1;
	for (; p.has(`group${m}`);) m++;
	let h = a.map((t) => {
		let r = o.find((e) => e.id === t.id), a = e.text.slice(t.start, t.end), l = n === "stackfield" ? i === 2 ? f : 0 : r.x - s, u = n === "stackfield" ? i === 2 ? 0 : f : r.y - c;
		n === "stackfield" && (f += i === 2 ? r.width : r.height);
		let d = Y(e, t, r, l, u);
		for (let e of d.sort((e, t) => t.start - e.start)) a = a.slice(0, e.start - t.start) + e.text + a.slice(e.end - t.start);
		return a;
	}), g = e.text.includes("\r\n") ? "\r\n" : "\n", _ = `<${n} name="group${m}" xleft="${Math.round(s)}" ytop="${Math.round(c)}" width="${Math.round(l)}" height="${Math.round(u)}" designbias="2" outlinewidth="0"${n === "stackfield" && i !== 1 ? ` orientation="${i}"` : ""} fieldstyle="0">${g}${h.join(g)}${g}</${n}>`, v = Math.min(...a.map((e) => e.start));
	return {
		uri: e.uri,
		version: e.version,
		edits: a.map((t) => ({
			start: t.start,
			end: t.end,
			expected: e.text.slice(t.start, t.end),
			text: t.start === v ? _ : ""
		}))
	};
}
function me(e, t, n, r, i) {
	let a = e.nodes.find((e) => e.id === t);
	if (!a || ![
		"subform",
		"flexibleform",
		"stackfield"
	].includes(a.kind)) throw Error("Select a subform, flexible form, or stack field");
	let o = new Set(n.map((e) => e.id));
	if (!a.children.length || a.children.some((e) => !o.has(e.id))) throw Error("Group contains non-field source; ungroup would lose it");
	let s = e.text.slice(a.openEnd, e.text.lastIndexOf("</", a.end - 1)), c = a.children.flatMap((t) => {
		let a = n.find((e) => e.id === t.id);
		return Y(e, t, a, a.x + r, a.y + i);
	});
	for (let e of c.sort((e, t) => t.start - e.start)) s = s.slice(0, e.start - a.openEnd) + e.text + s.slice(e.end - a.openEnd);
	return {
		uri: e.uri,
		version: e.version,
		edits: [{
			start: a.start,
			end: a.end,
			expected: e.text.slice(a.start, a.end),
			text: s
		}]
	};
}
//#endregion
//#region src/field-view.ts
var X = /* @__PURE__ */ new WeakMap();
function Z(e, t, n) {
	n !== "9" && n !== "11" && (t = void 0);
	let r = t ? X.get(t) : void 0;
	if (t && !r) {
		let e = document.createElement("canvas");
		e.width = t.width, e.height = t.height, e.getContext("2d")?.putImageData(new ImageData(new Uint8ClampedArray(t.rgba), e.width, e.height), 0, 0), r = e.toDataURL(), X.set(t, r);
	}
	e.style.backgroundImage = r ? `url(${r})` : "", e.style.backgroundRepeat = "no-repeat";
}
var he = /* @__PURE__ */ new Set([
	"flexibleform",
	"subform",
	"stackfield",
	"matrixfield",
	"viewportfield",
	"tablefield",
	"columnfield",
	"tabfolder",
	"tabpage",
	"tabbar",
	"tablebody",
	"tableheader"
]);
function Q(e, t) {
	let n = t.properties;
	Z(e, t.backgroundBitmap, n.bgpattern);
	let r = (n = t.bitmap, r = e) => {
		if (!n) return !1;
		let i = document.createElement("canvas");
		return i.width = n.width, i.height = n.height, i.getContext("2d")?.putImageData(new ImageData(new Uint8ClampedArray(n.rgba), i.width, i.height), 0, 0), Object.assign(i.style, {
			maxWidth: "100%",
			maxHeight: "100%",
			objectFit: "contain",
			flexShrink: "0"
		}), i.setAttribute("aria-hidden", "true"), r.append(i), !0;
	}, i = (t, n = {}) => {
		let r = document.createElement("span");
		return r.textContent = t, Object.assign(r.style, n), e.append(r), r;
	};
	if (e.style.textAlign = "left", t.kind === "columnfield" && t.prototype) {
		e.style.border = "0", e.style.padding = "0";
		let n = Number(t.properties.visualrowheight) * .096;
		if (!Number.isFinite(n) || n <= 0) return;
		let r = Math.min(200, Math.ceil(t.height / n));
		for (let i = 0; i < r; i++) {
			let r = document.createElement("span");
			Object.assign(r.style, {
				position: "absolute",
				left: "0",
				top: `${i * n}px`,
				width: "100%",
				height: `${n}px`,
				overflow: "hidden",
				border: "1px solid currentColor",
				boxSizing: "border-box"
			});
			let a = t.prototype.properties;
			J(r, a), t.prototype.kind !== "unknown" && Q(r, {
				...t,
				kind: t.prototype.kind,
				properties: a,
				prototype: void 0,
				bitmap: void 0,
				label: a.textlabel ?? a.defaultstring ?? "",
				choices: t.prototype.choices,
				height: n
			}), e.append(r);
		}
		return;
	}
	if (t.kind === "boxtrim") {
		n.outlinewidth === "0" && (e.style.border = "0"), e.textContent = t.label;
		return;
	}
	if (t.kind === "tabfield") {
		e.style.border = "1px solid currentColor", e.style.textAlign = "center", e.style.display = "flex", e.style.flexDirection = "column", e.style.alignItems = "center", e.style.justifyContent = "center", i(t.label), r();
		let n = e.querySelector("canvas");
		n && (n.style.width = "16px", n.style.height = "16px");
		return;
	}
	if (t.kind === "titletrim") {
		e.style.border = "0", e.style.background = "transparent", e.textContent = t.label;
		return;
	}
	if (t.kind === "palettefield") {
		e.style.display = "grid", e.style.gridTemplateColumns = `repeat(${Math.max(1, Math.min(100, Number(n.columns) || 1))},minmax(0,1fr))`;
		for (let e of (t.choices ?? []).slice(0, 100)) {
			let t = i(e.bitmap ? "" : e.label || e.value, {
				border: "1px solid #777",
				textAlign: "center",
				display: "grid",
				placeItems: "center"
			});
			r(e.bitmap, t);
		}
		e.setAttribute("aria-description", "Palette values; bitmap previews require a decoded host image");
		return;
	}
	if (t.kind === "controlbutton") {
		e.style.border = "1px solid #777", e.style.backgroundColor = "#ddd", e.style.textAlign = "center", i("▾", {
			fontSize: "10px",
			lineHeight: "12px"
		});
		return;
	}
	if (he.has(t.kind)) {
		e.style.border = t.kind === "subform" && n.outlinewidth !== "0" ? "1px solid #777" : "0", n.bgpattern === "2" && (e.style.backgroundColor = "transparent"), n.groupboxlabel && i(n.groupboxlabel, {
			position: "absolute",
			top: "0",
			left: "6px"
		});
		return;
	}
	if (t.kind === "segmentshape") {
		e.style.background = "transparent", e.style.border = "0";
		let t = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		t.setAttribute("viewBox", `0 0 ${Number(n.width)} ${Number(n.height)}`), t.setAttribute("preserveAspectRatio", "none"), t.style.width = "100%", t.style.height = "100%";
		let r = document.createElementNS(t.namespaceURI, "line");
		for (let e of [1, 2]) for (let t of ["x", "y"]) r.setAttribute(`${t}${e}`, String(Number(n[`point${e}${t}`] ?? 0) - Number(n[t === "x" ? "xleft" : "ytop"])));
		r.setAttribute("stroke", "currentColor"), r.setAttribute("vector-effect", "non-scaling-stroke"), t.append(r), e.append(t);
		return;
	}
	if (["rectangleshape", "ellipseshape"].includes(t.kind)) {
		e.style.border = n.linewidth === "0" ? "0" : "1px solid currentColor", n.bgpattern === "2" && (e.style.backgroundColor = "transparent");
		return;
	}
	if (["imagefield", "imagetrim"].includes(t.kind)) {
		if (r()) {
			e.style.display = "grid", e.style.placeItems = "center";
			return;
		}
		t.kind === "imagefield" ? (e.style.border = "3px solid #111", e.style.boxSizing = "content-box", e.style.fontWeight = "bold") : e.style.border = "0", e.style.textAlign = "center", i("Image", {
			display: "grid",
			placeItems: "center",
			width: "100%",
			height: "100%"
		}), e.setAttribute("aria-description", "Bitmap preview requires a decoded host image");
		return;
	}
	if ([
		"listfield",
		"radiofield",
		"optionfield"
	].includes(t.kind)) {
		let r = t.choices ?? [], a = n.defaultstring || r[Number(n.curenumindex ?? 1) - 1]?.value;
		if (t.kind === "optionfield") {
			i(r[Number(n.curenumindex ?? 1) - 1]?.label ?? "", { paddingLeft: "3px" }), i("▾", {
				position: "absolute",
				right: "2px",
				top: "0"
			});
			return;
		}
		t.kind === "listfield" && (e.style.backgroundColor = "white"), t.kind === "radiofield" && (e.style.border = n.outlinewidth === "0" ? "0" : "1px solid currentColor", e.style.display = "flex", e.style.flexDirection = n.orientation === "2" ? "row" : "column", e.style.alignItems = n.orientation === "2" ? "center" : "flex-start", e.style.gap = "8px");
		let o = Math.max(14, Number(n.typesize ?? 8) * 96 / 72 * 1.4), s = Math.min(50, Math.ceil(t.height / o));
		for (let e of r.slice(0, s)) {
			if (t.kind === "radiofield") {
				let t = i("", {
					display: "inline-flex",
					alignItems: "center",
					gap: "3px",
					whiteSpace: "nowrap",
					height: `${o}px`
				}), n = document.createElement("span");
				Object.assign(n.style, {
					display: "inline-block",
					width: "13px",
					height: "13px",
					borderRadius: "50%",
					border: `1px solid ${e.value === a ? "#0067c0" : "#777"}`,
					background: e.value === a ? "radial-gradient(circle,white 0 2px,#0067c0 3px)" : "#fafafa",
					flexShrink: "0"
				}), t.append(n, document.createTextNode(e.label));
				continue;
			}
			let n = i(t.kind === "radiofield" ? `${e.value === a ? "◉" : "○"} ${e.label}` : e.label, {
				display: "block",
				height: `${o}px`,
				paddingLeft: "3px"
			});
			t.kind === "listfield" && e.value === a && (n.style.background = "#0078d7", n.style.color = "white");
		}
		return;
	}
	if ([
		"scrollbarfield",
		"sliderfield",
		"barfield"
	].includes(t.kind)) {
		let r = n.orientation === "1", a = Number(n.defaultstring ?? 0), o = Number(n.minvalue ?? 0), s = Number(n.maxvalue ?? o), c = s > o ? Math.min(1, Math.max(0, (a - o) / (s - o))) : 0;
		if (t.kind === "barfield") {
			i("", {
				position: "absolute",
				left: "0",
				bottom: "0",
				width: `${r ? 100 : c * 100}%`,
				height: `${r ? c * 100 : 100}%`,
				background: "currentColor"
			});
			return;
		}
		e.style.background = "#ddd", e.style.border = t.kind === "sliderfield" ? "0" : "1px solid #888", t.kind === "scrollbarfield" && (i(r ? "▲" : "◀", {
			position: "absolute",
			left: "0",
			top: "0"
		}), i(r ? "▼" : "▶", {
			position: "absolute",
			right: "0",
			bottom: "0"
		}));
		let l = Number(n.elevatorsize ?? 20);
		i("", {
			position: "absolute",
			left: r ? "2px" : `${Math.max(12, c * (t.width - 24))}px`,
			top: r ? `${Math.max(12, c * (t.height - 24))}px` : "2px",
			width: r ? "calc(100% - 4px)" : `${l}%`,
			height: r ? `${l}%` : "calc(100% - 4px)",
			border: "1px solid #777",
			background: "#eee"
		});
		return;
	}
	if (t.kind === "treeviewfield" || t.kind === "listviewfield") {
		if (e.style.backgroundColor = "white", e.style.border = "1px solid #777", t.kind === "listviewfield" && n.hascolumnheaders !== "0") {
			let n = document.createElement("span");
			Object.assign(n.style, {
				display: "flex",
				height: "20px",
				background: "#eee",
				borderBottom: "1px solid #aaa"
			});
			for (let e of t.columns ?? []) {
				let t = document.createElement("span");
				t.textContent = e.label, Object.assign(t.style, {
					flex: `0 0 ${e.width * 96 / 1e3}px`,
					padding: "3px",
					borderRight: "1px solid #aaa"
				}), n.append(t);
			}
			e.append(n);
		}
		for (let e of (t.choices ?? []).slice(0, 50)) i(e.label, { display: "block" });
		return;
	}
	if (["buttonfield", "popupbutton"].includes(t.kind) && t.bitmap) {
		e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", n.buttonstyle === "2" && n.bgpattern === "-1" && (e.style.background = "transparent", e.style.border = "0"), r(), n.buttonstyle !== "2" && n.hastextlabel !== "0" && i(t.label);
		return;
	}
	e.textContent = t.kind === "togglefield" ? `${n.defaultstring === "1" ? "☒" : "☐"} ${t.label}` : t.label, ["buttonfield", "popupbutton"].includes(t.kind) && (e.style.textAlign = "center");
}
//#endregion
//#region src/field-visibility.ts
function ge(e, t) {
	return (e.pageScopes ?? []).every((e) => e.index === (t.get(e.folderId) ?? 0));
}
function _e(e, t) {
	let n = e.x, r = e.y, i = e.x + e.width, a = e.y + e.height, o = e.parentId, s = /* @__PURE__ */ new Set();
	for (; o && !s.has(o);) {
		s.add(o);
		let e = t.get(o);
		if (!e) break;
		[
			"tabpage",
			"viewportfield",
			"tablebody"
		].includes(e.kind) && (n = Math.max(n, e.x), r = Math.max(r, e.y), i = Math.min(i, e.x + e.width), a = Math.min(a, e.y + e.height)), o = e.parentId;
	}
	let c = [
		Math.max(0, r - e.y),
		Math.max(0, e.x + e.width - i),
		Math.max(0, e.y + e.height - a),
		Math.max(0, n - e.x)
	];
	return c.some((e) => e > 0) ? `inset(${c.map((e) => `${e}px`).join(" ")})` : void 0;
}
//#endregion
//#region src/designer.ts
var $ = class extends HTMLElement {
	#e = this.attachShadow({ mode: "open" });
	#t;
	#n;
	#r = /* @__PURE__ */ new Set();
	#i = "0";
	#a = 1;
	#o = {
		left: 0,
		top: 0
	};
	#s = 0;
	#c = "All";
	#l = !1;
	#u;
	#d = !1;
	get readOnly() {
		return this.#d;
	}
	set readOnly(e) {
		this.#d !== e && (this.#d = e, this.#u?.(), this.#i = "0", this.#_());
	}
	#f = !1;
	#p = /* @__PURE__ */ new Map();
	set document(e) {
		e.uri !== this.#t?.uri && (this.#p.clear(), this.#r.clear(), this.#n = void 0), this.#t = e, this.#r = new Set([...this.#r].filter((t) => e.fields.some((e) => e.id === t))), e.fields.some((e) => e.id === this.#n) || (this.#n = [...this.#r].at(-1)), this.#_();
	}
	get document() {
		return this.#t;
	}
	get zoom() {
		return this.#a;
	}
	get selectedFieldId() {
		return this.#n;
	}
	get selectedFieldIds() {
		return [...this.#r];
	}
	requestSourceNavigation(e = this.#n) {
		let t = this.#t, n = t?.fields.find((t) => t.id === e);
		t && n?.source && this.#m("source-navigation", {
			uri: t.uri,
			version: t.version,
			fieldId: n.id,
			range: n.source
		});
	}
	selectFields(e) {
		this.#r = new Set(e.filter((e) => this.#t?.fields.some((t) => t.id === e))), this.#n = [...this.#r].at(-1), this.#i = "0", this.#_(), this.#m("selection-change", {
			uri: this.#t?.uri,
			version: this.#t?.version,
			fieldId: this.#n,
			fieldIds: [...this.#r]
		});
	}
	deleteSelection() {
		if (this.#d) return;
		let e = this.#t;
		if (e?.source && this.#r.size) try {
			let t = f(e.source, [...this.#r]);
			this.#r.clear(), this.#n = void 0, this.#h(t);
		} catch (e) {
			this.#g(e);
		}
	}
	groupSelection(e, t = 1) {
		if (this.#d) return;
		let n = this.#t;
		if (n?.source) try {
			let r = n.fields.filter((e) => this.#r.has(e.id)).map((e) => ({
				id: e.id,
				x: Number(e.properties.xleft),
				y: Number(e.properties.ytop),
				width: Number(e.properties.width) + F(e.kind),
				height: Number(e.properties.height) + F(e.kind),
				properties: e.properties
			})), i = pe(n.source, r, e, void 0, t);
			this.#r.clear(), this.#n = void 0, this.#h(i);
			let a = this.#t?.fields.find((t) => t.kind === e && !n.fields.some((e) => e.id === t.id));
			a && this.selectField(a.id);
		} catch (e) {
			this.#g(e);
		}
	}
	ungroupSelection() {
		if (this.#d) return;
		let e = this.#t, t = e?.fields.find((e) => e.id === this.#n);
		if (e?.source && t && this.#r.size === 1) try {
			let n = e.fields.filter((e) => e.parentId === t.id).map((e) => ({
				id: e.id,
				x: Number(e.properties.xleft),
				y: Number(e.properties.ytop),
				width: e.width,
				height: e.height,
				properties: e.properties
			})), r = me(e.source, t.id, n, Number(t.properties.xleft), Number(t.properties.ytop));
			this.#r.clear(), this.#n = void 0, this.#h(r);
		} catch (e) {
			this.#g(e);
		}
	}
	selectField(e) {
		for (let t of this.#t?.fields.find((t) => t.id === e)?.pageScopes ?? []) this.#p.set(t.folderId, t.index);
		let t = this.#t?.fields.find((t) => t.id === e);
		if (!t) return;
		let n = this.#e.querySelector(".viewport");
		if (n) {
			let e = t.x * this.#a + 48, r = t.y * this.#a + 64;
			(e < n.scrollLeft || e + t.width * this.#a > n.scrollLeft + n.clientWidth) && (n.scrollLeft = Math.max(0, e - 48)), (r < n.scrollTop || r + t.height * this.#a > n.scrollTop + n.clientHeight) && (n.scrollTop = Math.max(0, r - 64));
		}
		this.#n = e, this.#r = /* @__PURE__ */ new Set([e]), this.#i = "0", this.#_(), this.#m("selection-change", {
			uri: this.#t.uri,
			version: this.#t.version,
			fieldId: e,
			fieldIds: [e]
		});
	}
	selectFrame() {
		this.#n = void 0, this.#r.clear(), this.#_(), this.#m("selection-change", {
			uri: this.#t?.uri,
			version: this.#t?.version,
			fieldIds: []
		});
	}
	connectedCallback() {
		this.tabIndex = 0, this.onkeydown = (e) => {
			e.key !== "Delete" || e.composedPath().some((e) => e instanceof HTMLInputElement || e instanceof HTMLSelectElement || e instanceof HTMLTextAreaElement) || (e.preventDefault(), this.deleteSelection());
		}, this.#_();
	}
	#m(e, t) {
		this.dispatchEvent(new CustomEvent(e, {
			detail: t,
			bubbles: !0,
			composed: !0
		}));
	}
	#h(e) {
		this.#d || this.#m("edit-intent", e);
	}
	#g(e) {
		this.#m("designer-error", String(e));
	}
	#_() {
		let e = this.#e.querySelector(".viewport");
		e && (this.#o = {
			left: e.scrollLeft,
			top: e.scrollTop
		});
		let t = this.#e.querySelector(".properties");
		t && (this.#s = t.scrollTop), this.#e.innerHTML = "<style>\n   :host{display:block;height:100%;font:12px Arial,sans-serif;color:#dce3ee;background:#202733}*{box-sizing:border-box}button,input,select{font:inherit;color:inherit}button{cursor:pointer}button:disabled{cursor:default;opacity:.4}\n   main{display:grid;grid-template-columns:90px minmax(0,1fr) 310px;height:100%}.palette{border-right:1px solid #526074;background:#293341;padding:6px}.palette h3,.inspector h3{font-size:12px;font-weight:normal;margin:0 0 7px}.tools{display:grid;grid-template-columns:repeat(3,24px);gap:2px}.tool{height:25px;padding:0;border:1px solid #647185;border-radius:0;background:#e5e7e9;color:#10244b;font:bold 14px Arial}.tool[aria-pressed=true]{background:#9fcaff;border-color:#489dff;box-shadow:inset 0 0 0 1px #207de0}\n   .workarea{position:relative;min-width:0;overflow:hidden}.zoomtools{position:absolute;z-index:5;left:16px;top:12px;display:flex;align-items:center;gap:3px;background:#303c4e;border:1px solid #536078;padding:3px;box-shadow:0 2px 6px #0003}.zoomtools button{width:26px;height:24px;padding:0;border:0;background:transparent;font-size:18px}.zoomtools button:hover{background:#526074}.zoomtools span{min-width:40px;text-align:center;font-size:11px}.viewport{height:100%;overflow:auto;padding:64px 48px;touch-action:none;background-color:#1e2530;background-image:radial-gradient(#52607466 .6px,transparent .6px);background-size:12px 12px}.extent{position:relative;min-width:100%;min-height:100%}.canvas{position:absolute;transform-origin:top left;box-shadow:0 4px 24px #0008;background:#f0f0f0;color:#111;outline:1px solid #9299a5}.surface{position:absolute;inset:0;overflow:hidden}.canvas.window-selected{outline:1px solid #56a0ff}\n   .field{position:absolute;padding:0;border-radius:0;color:#111;font:11px Arial;white-space:nowrap;overflow:hidden;background:#f0f0f0;border:1px solid #111}.field.selected{outline:1px dotted #165da5;outline-offset:2px}.entryfield{background:white;text-align:left;box-sizing:content-box}.buttonfield{box-sizing:content-box;box-shadow:inset -1px -1px #777}.freetrim{background:transparent;border:0;text-align:left}.boxtrim{background:transparent;text-align:left}.ellipseshape{border-radius:50%;background:transparent}.linesegmentshape{border:0;border-top:1px solid #111;background:transparent}.togglefield{background:transparent;border:0;text-align:left}.unsupported{background:repeating-linear-gradient(45deg,#ddd,#ddd 4px,#eee 4px,#eee 8px);color:#555}.handle{position:absolute;width:7px;height:7px;background:#eff6ff;border:1px solid #216dcc;z-index:4;transform:translate(-50%,-50%);padding:0}.preview{position:absolute;border:1px dashed #216dcc;background:#499aff22;pointer-events:none}\n   .inspector{display:flex;flex-direction:column;min-height:0;min-width:0;background:#293341;border-left:1px solid #526074}.inspector h3{padding:7px 7px 0}.selectors{padding:0 4px 3px;display:grid;grid-template-columns:2fr 1fr;gap:2px}.selectors .selection{grid-column:1/-1}.selectors select,.selectors input{height:21px;width:100%;min-width:0;border:1px solid #68758a;background:#202938;padding:1px 3px;border-radius:0}.properties{flex:1;overflow:auto;padding:2px 5px;background:#252e3b}.row{display:grid;grid-template-columns:46% 54%;min-height:18px;align-items:center}.row label{padding:1px 2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.value{min-width:0;width:100%;height:18px;padding:0 2px;background:transparent;border:1px solid transparent;border-radius:0;outline:0}.value:hover{border-color:#536078}.value:focus{background:#142237;border-color:#58a5ff}.value:disabled{color:#a9b4c6;opacity:1}.value option{background:#252e3b}.help{height:39px;padding:5px 7px;border-top:1px solid #526074;font-size:11px;color:#b3c1d5;overflow:hidden}\n  </style><main><nav class=\"palette\" aria-label=\"Field palette\"><h3>Field Palette</h3><div class=\"tools\"></div></nav><section class=\"workarea\"><div class=\"zoomtools\" aria-label=\"Zoom controls\"><button data-action=\"out\" aria-label=\"Zoom out\" title=\"Zoom out\">−</button><span></span><button data-action=\"in\" aria-label=\"Zoom in\" title=\"Zoom in\">+</button><button data-action=\"reset\" aria-label=\"Actual size\" title=\"Actual size\">⊙</button><button data-action=\"fit\" aria-label=\"Fit frame\" title=\"Fit frame\">⛶</button></div><div class=\"viewport\"><div class=\"extent\"><div class=\"canvas\"><div class=\"surface\"></div></div></div></div></section><aside class=\"inspector\"><h3>Property Inspector</h3><div class=\"selectors\"><select class=\"selection\" aria-label=\"Selected object\"></select><input class=\"objectname\" readonly aria-label=\"Object name\"><select class=\"filter\" aria-label=\"Property filter\"><option>All</option><option>Appearance</option><option>Layout</option><option>Position and Size</option><option>Bias</option><option>Miscellaneous</option></select></div><div class=\"properties\"></div><div class=\"help\">Select a property to see its origin.</div></aside></main>", this.#d && (this.#e.querySelector(".palette").style.display = "none", this.#e.querySelector("main").style.gridTemplateColumns = "minmax(0,1fr) 310px");
		let n = this.#t;
		if (!n) return;
		let r = this.#e.querySelector(".viewport"), i = this.#e.querySelector(".canvas"), a = this.#e.querySelector(".surface"), o = this.#e.querySelector(".extent");
		i.classList.toggle("window-selected", !this.#n), Object.assign(i.style, {
			width: `${n.width}px`,
			height: `${n.height}px`,
			transform: `scale(${this.#a})`
		}), J(i, n.formProperties ?? {}), Z(i, n.backgroundBitmap, n.formProperties?.bgpattern), o.style.width = `${n.width * this.#a + 24}px`, o.style.height = `${n.height * this.#a + 24}px`, this.#e.querySelector(".zoomtools span").textContent = `${Math.round(this.#a * 100)}%`;
		for (let e of this.#e.querySelectorAll("[data-action]")) e.onclick = () => {
			let t = e.dataset.action;
			this.#a = t === "reset" ? 1 : t === "fit" ? Math.max(.1, Math.min(4, (r.clientWidth - 100) / n.width, (r.clientHeight - 130) / n.height)) : Math.max(.1, Math.min(4, this.#a + (t === "in" ? .25 : -.25))), this.#_();
		};
		for (let e of n.palette ?? [{
			id: "0",
			label: "Select",
			icon: "↖"
		}]) {
			let t = document.createElement("button");
			t.className = "tool", t.textContent = e.icon, t.title = e.label + (e.className ? ` (${e.className})` : "") + (e.id !== "0" && !e.kind ? " — definition not supported yet" : ""), t.setAttribute("aria-label", e.label + (e.className ? ` (${e.className})` : "")), t.setAttribute("aria-pressed", String(e.id === this.#i)), t.disabled = e.id !== "0" && !e.kind, t.dataset.tool = e.id, t.onclick = () => {
				this.#i = e.id, this.#_();
			}, this.#e.querySelector(".tools").append(t);
		}
		let s = n.fields.find((e) => e.id === this.#n), c = n.fields.filter((e) => this.#C(e)), l = new Map(n.fields.map((e) => [e.id, e])), u = c.length <= 1e3 ? c : c.filter((e) => e.id === this.#n || e.x + e.width >= (this.#o.left - 48) / this.#a && e.y + e.height >= (this.#o.top - 64) / this.#a && e.x <= (this.#o.left + r.clientWidth) / this.#a && e.y <= (this.#o.top + r.clientHeight) / this.#a).slice(0, 1e3);
		for (let e of u) {
			let t = document.createElement("button");
			t.type = "button", t.dataset.field = e.id, t.className = `field ${e.kind}${this.#r.has(e.id) ? " selected" : ""}`, t.title = `${e.name} (${e.kind.toUpperCase()})`, Object.assign(t.style, {
				left: `${e.x}px`,
				top: `${e.y}px`,
				width: `${e.width}px`,
				height: `${e.height}px`
			}), J(t, e.properties), Q(t, e.tabTarget && (this.#p.get(e.tabTarget.folderId) ?? 0) === e.tabTarget.index && e.selectedBitmap ? {
				...e,
				bitmap: e.selectedBitmap
			} : e);
			let n = _e(e, l);
			if (n && (t.style.clipPath = n), e.tabTarget) {
				let n = (this.#p.get(e.tabTarget.folderId) ?? 0) === e.tabTarget.index;
				t.setAttribute("role", "tab"), t.setAttribute("aria-selected", String(n)), n && (t.style.fontWeight = "bold", t.style.borderBottomColor = "transparent");
			}
			t.onpointerdown = (t) => {
				if (!(t.button !== 0 || t.altKey) && (t.stopPropagation(), this.#i === "0")) {
					if (this.focus({ preventScroll: !0 }), e.tabTarget && !t.ctrlKey && !t.shiftKey) {
						this.#p.set(e.tabTarget.folderId, e.tabTarget.index), this.selectField(e.id);
						return;
					}
					if (t.ctrlKey) {
						e.parentId ? this.selectField(e.parentId) : this.selectFrame();
						return;
					}
					if (t.shiftKey) {
						let t = new Set(this.#r);
						t.has(e.id) ? t.delete(e.id) : t.add(e.id), this.selectFields([...t]);
						return;
					}
					this.#r.has(e.id) || this.selectField(e.id), this.#w(t, e);
				}
			}, a.append(t);
		}
		!this.#d && s && this.#r.size === 1 && n.source ? this.#y(i, s.x, s.y, s.width, s.height, (e, t) => this.#T(e, t, s)) : !this.#d && !s && (n.metadata || n.source) && this.#y(i, 0, 0, n.width, n.height, (e, t) => this.#T(e, t)), a.onpointerdown = (e) => {
			if (e.button !== 0 || e.altKey) return;
			let t = n.palette?.find((e) => e.id === this.#i);
			t?.kind ? this.#E(e, t) : e.target === a && this.#S(e);
		}, r.onpointerdown = (e) => {
			if (e.button !== 1 && !e.altKey) return;
			e.preventDefault();
			let { clientX: t, clientY: n } = e, i = r.scrollLeft, a = r.scrollTop;
			this.#b(e, (e) => {
				r.scrollLeft = i + t - e.clientX, r.scrollTop = a + n - e.clientY;
			}, () => this.#_());
		};
		let d = this.#e.querySelector(".selection"), f = n.fields.slice(0, 1e3);
		s && !f.includes(s) && f.push(s);
		for (let [e, t] of [["", n.title.replace(/\.wml$/i, "")], ...f.map((e) => [e.id, `${e.name || "(unnamed)"} (${e.kind.toUpperCase()})`])]) {
			let n = document.createElement("option");
			n.value = e, n.textContent = t, d.append(n);
		}
		if (n.fields.length > 1e3) {
			let e = document.createElement("option");
			e.disabled = !0, e.textContent = "More objects: select on canvas", d.append(e);
		}
		d.value = this.#n ?? "", d.onchange = () => d.value ? this.selectField(d.value) : this.selectFrame(), this.#e.querySelector(".objectname").value = this.#r.size > 1 ? `${this.#r.size} fields` : s?.name ?? n.title.replace(/\.wml$/i, "");
		let p = this.#e.querySelector(".filter");
		p.value = this.#c, p.onchange = () => {
			this.#c = p.value, this.#s = 0, this.#_();
		}, this.#v(s), r.scrollLeft = this.#o.left, r.scrollTop = this.#o.top, r.onscroll = () => {
			n.fields.length <= 1e3 || this.#l || this.#f || (this.#f = !0, requestAnimationFrame(() => {
				this.#f = !1, this.#_();
			}));
		}, this.#e.querySelector(".properties").scrollTop = this.#s;
	}
	#v(e) {
		let t = this.#t, n = e ? ce(e.kind, e.properties) : B, r = this.#e.querySelector(".properties"), i = this.#e.querySelector(".help"), a = /^(Abs|Outer|[XY]|Width|Height|Window(Width|Height|Left|Top)|AnchorPoint|Gravity)/, c = /Color|Bitmap|Pattern|Style|Outline|TypeFace|TypeSize|IsBold|IsItalic|IsPlain|IsReverse/;
		for (let l of n) {
			if (this.#c === "Position and Size" && !a.test(l) || this.#c === "Appearance" && !c.test(l) || this.#c === "Layout" && !/Anchor|Gravity|Margin|Lines|Chars|Alignment/.test(l) || this.#c === "Bias" && !/Bias/.test(l) || this.#c === "Miscellaneous" && (a.test(l) || c.test(l) || /Bias|Anchor|Gravity|Margin|Lines|Chars|Alignment/.test(l))) continue;
			let n = e ? ue(l) : le(l), u = [
				"bgcolor",
				"bgpattern",
				"transparentcolor"
			].includes(n), d = e?.properties ?? (u ? t.formProperties : {}), f = e || u ? d?.[n] : t.metadata?.attributes[n]?.value, p = e ? e.propertyOrigins?.[n] : u ? t.formOrigins?.[n] : f === void 0 ? void 0 : "Frame metadata";
			if (e && f === void 0 && [
				"entryfield",
				"buttonfield",
				"boxtrim",
				"imagefield",
				"imagetrim"
			].includes(e.kind)) {
				let t = F(e.kind), r = Number(e.properties.width) + t, i = Number(e.properties.height) + t, a = N(e.x + 3), o = N(e.y + 4);
				f = {
					outerwidth: String(r),
					outerheight: String(i),
					absxleft: String(a),
					absxright: String(a + r),
					absytop: String(o),
					absybottom: String(o + i)
				}[n], f !== void 0 && (p = "Derived geometry (calibrated native controls)");
			}
			!e && !t.metadata && ["windowwidth", "windowheight"].includes(n) && (f = String(Math.round((n === "windowwidth" ? t.width : t.height) / M)), p = "WML topform (no companion)");
			let m = e?.kind ?? "framesource", g = t.source?.nodes.find((n) => n.id === (e?.id ?? t.formId)), _ = e || u ? !!g?.attributes[n] || !!g?.children.some((e) => e.kind === n && e.value !== void 0) : !!t.metadata?.attributes[n], v;
			if (!e && !u && t.metadata?.attributes.templatename?.value === "empty_frame" && (v = oe[n], f === void 0 && v !== void 0 && (f = v, p = "empty_frame template default")), (e || u) && g) {
				let e = { ...g.attributes };
				delete e[n];
				try {
					v = o({
						...g,
						attributes: e,
						children: g.children.filter((e) => e.kind !== n || e.value === void 0)
					}, t.defaults ?? [])[n]?.value;
				} catch {}
			}
			let y = v === void 0 ? "(Native default — unresolved)" : `${G(m, n, v)} (Native default)`, b = I[m]?.[n] ?? (u ? "xs:integer" : void 0), x = !this.#d && !!b && !!t.source && e?.propertyOrigins?.[n] !== "Native container layout" && (e ? !0 : u || !!t.metadata || ["windowwidth", "windowheight"].includes(n)), S = document.createElement("div");
			S.className = "row";
			let C = document.createElement("label");
			C.textContent = l;
			let w, T = b === "or_bool", E = W[n];
			if (T || E) {
				let e = document.createElement("select");
				w = e;
				{
					let t = document.createElement("option");
					t.value = "__inherit__", t.textContent = y, e.append(t);
				}
				for (let [t, n] of Object.entries(T ? {
					0: "FALSE",
					1: "TRUE"
				} : E)) {
					let r = document.createElement("option");
					r.value = t, r.textContent = n, e.append(r);
				}
				if (f !== void 0 && !Array.from(e.options).some((e) => e.value === f)) {
					let t = document.createElement("option");
					t.value = f, t.textContent = f, e.append(t);
				}
				e.value = _ ? f ?? "__inherit__" : "__inherit__";
			} else {
				let e = document.createElement("input");
				if (w = e, e.value = f === void 0 ? "" : G(m, n, f), e.placeholder = x ? "(default)" : "(native / derived)", x) {
					let t = document.createElement("datalist");
					t.id = `defaults-${n}`;
					let r = document.createElement("option");
					r.value = y, t.append(r), S.append(t), e.setAttribute("list", t.id);
				}
			}
			w.className = "value", w.setAttribute("aria-label", n), w.disabled = !x;
			let D = `${l} · ${p ?? "Not supplied; native default unresolved"}${a.test(l) ? " · 1/1000 inch" : ""}${x ? "" : " · read only"}`;
			w.title = D, S.onpointerenter = () => {
				i.textContent = D;
			}, w.onfocus = () => {
				i.textContent = D;
			}, w.onchange = () => {
				if (!this.#d) try {
					let r = w.value === "__inherit__" || w.value === y ? null : w.value;
					r !== null && de(m, n, r), w.setCustomValidity(""), e ? this.#h(s(t.source, e.id, n, r)) : u ? this.#h(s(t.source, t.formId, n, r)) : t.metadata ? this.#h(h(t.metadata, { [n]: r })) : this.#h(s(t.source, t.formId, n === "windowwidth" ? "width" : "height", r));
				} catch (e) {
					w.setCustomValidity(String(e)), i.textContent = String(e), this.#g(e);
				}
			}, S.append(C, w), r.append(S);
		}
	}
	#y(e, t, n, r, i, a) {
		for (let [o, s, c] of [
			[
				"nw",
				0,
				0
			],
			[
				"n",
				.5,
				0
			],
			[
				"ne",
				1,
				0
			],
			[
				"e",
				1,
				.5
			],
			[
				"se",
				1,
				1
			],
			[
				"s",
				.5,
				1
			],
			[
				"sw",
				0,
				1
			],
			[
				"w",
				0,
				.5
			]
		]) {
			let l = document.createElement("button");
			l.className = "handle", l.dataset.resize = o, l.setAttribute("aria-label", `Resize ${o}`), Object.assign(l.style, {
				left: `${t + r * s}px`,
				top: `${n + i * c}px`,
				cursor: `${o}-resize`
			}), l.onpointerdown = (e) => {
				e.stopPropagation(), e.button === 0 && a(e, o);
			}, e.append(l);
		}
	}
	#b(e, t, n) {
		e.preventDefault(), this.#l = !0;
		let r = new AbortController(), i = { signal: r.signal }, a = (e) => {
			r.abort(), this.#u = void 0, this.#l = !1, n(e);
		};
		this.#u = () => a(!0), window.addEventListener("pointermove", (n) => {
			n.pointerId === e.pointerId && t(n);
		}, i), window.addEventListener("pointerup", (t) => {
			t.pointerId === e.pointerId && a(!1);
		}, i), window.addEventListener("pointercancel", () => a(!0), i), window.addEventListener("blur", () => a(!0), i), window.addEventListener("keydown", (e) => {
			e.key === "Escape" && a(!0);
		}, i);
	}
	#x(e, t) {
		let n = this.#t;
		if (!n.source) return;
		e.kind === "segmentshape" && (t = P(e.properties, t));
		let r = Object.entries(t).flatMap(([t, r]) => s(n.source, e.id, t, String(r)).edits);
		this.#h({
			uri: n.uri,
			version: n.version,
			edits: r
		});
	}
	#S(e) {
		this.focus({ preventScroll: !0 });
		let t = this.#t, n = this.#e.querySelector(".canvas"), r = n.getBoundingClientRect(), i = (e.clientX - r.left) / this.#a, a = (e.clientY - r.top) / this.#a, o = [...this.#r], s = document.createElement("div");
		s.className = "preview", n.append(s);
		let c = 0, l = 0;
		this.#b(e, (t) => {
			c = (t.clientX - e.clientX) / this.#a, l = (t.clientY - e.clientY) / this.#a, Object.assign(s.style, {
				left: `${Math.min(i, i + c)}px`,
				top: `${Math.min(a, a + l)}px`,
				width: `${Math.abs(c)}px`,
				height: `${Math.abs(l)}px`
			});
		}, (n) => {
			if (n) {
				this.#_();
				return;
			}
			if (Math.abs(c) < 4 && Math.abs(l) < 4) {
				this.selectFrame();
				return;
			}
			let r = Math.min(i, i + c), s = Math.min(a, a + l), u = Math.max(i, i + c), d = Math.max(a, a + l), f = t.fields.filter((e) => this.#C(e) && e.x >= r && e.y >= s && e.x + e.width <= u && e.y + e.height <= d).map((e) => e.id);
			this.selectFields(e.shiftKey ? [.../* @__PURE__ */ new Set([...o, ...f])] : f);
		});
	}
	#C(e) {
		return ge(e, this.#p);
	}
	#w(e, t) {
		if (this.#d || !this.#t?.source) return;
		let n = this.#t, r = d(n.source, [...this.#r]), i = new Set(r.map((e) => e.id)), a = n.fields.filter((e) => i.has(e.id)), o = a.map((e) => n.fields.find((t) => t.id === e.parentId)).find((e) => e && ["stackfield", "matrixfield"].includes(e.kind));
		if (o) {
			if (o.kind !== "stackfield" || a.length !== 1) {
				this.#g(Error("Drag one stack child to reorder it; matrix cell movement is not yet supported"));
				return;
			}
			let t = n.fields.filter((e) => e.parentId === o.id), r = a[0], i = o.properties.orientation === "2", s = 0;
			this.#b(e, (t) => {
				s = ((i ? t.clientX : t.clientY) - (i ? e.clientX : e.clientY)) / this.#a;
			}, (e) => {
				if (e || Math.abs(s) <= 1) {
					this.#_();
					return;
				}
				let a = (i ? r.x + r.width / 2 : r.y + r.height / 2) + s, c = t.filter((e) => e.id !== r.id), l = c.findIndex((e) => a < (i ? e.x + e.width / 2 : e.y + e.height / 2));
				if (c.splice(l < 0 ? c.length : l, 0, r), c.every((e, n) => e.id === t[n].id)) {
					this.#_();
					return;
				}
				try {
					this.#r.clear(), this.#n = void 0, this.#h(fe(n.source, o.id, c.map((e) => ({
						id: e.id,
						x: Number(e.properties.xleft),
						y: Number(e.properties.ytop),
						properties: e.properties,
						width: Number(e.properties.width) + F(e.kind),
						height: Number(e.properties.height) + F(e.kind)
					})), i ? 2 : 1)), this.selectField(o.id);
				} catch (e) {
					this.#g(e), this.#_();
				}
			});
			return;
		}
		let c = new Map(n.source.nodes.map((e) => [e.id, e])), l = n.fields.filter((e) => {
			let t = c.get(e.id);
			for (; t;) {
				if (i.has(t.id)) return !0;
				t = c.get(t.parentId ?? "");
			}
			return !1;
		}), u = 0, f = 0, p = new Map(Array.from(this.#e.querySelectorAll("[data-field]")).map((e) => [e.dataset.field, e]));
		this.#b(e, (t) => {
			u = (t.clientX - e.clientX) / this.#a, f = (t.clientY - e.clientY) / this.#a;
			for (let e of l) {
				let t = p.get(e.id);
				t && Object.assign(t.style, {
					left: `${e.x + u}px`,
					top: `${e.y + f}px`
				});
			}
		}, (e) => {
			!e && (Math.abs(u) > 1 || Math.abs(f) > 1) ? this.#h({
				uri: n.uri,
				version: n.version,
				edits: a.flatMap((e) => {
					let t = {
						xleft: N(Number(e.properties.xleft) * M + u),
						ytop: N(Number(e.properties.ytop) * M + f)
					};
					return e.kind === "segmentshape" && (t = P(e.properties, t)), Object.entries(t).flatMap(([t, r]) => s(n.source, e.id, t, String(r)).edits);
				})
			}) : this.#_();
		});
	}
	#T(e, t, n) {
		if (this.#d) return;
		let r = this.#t, i = n?.x ?? 0, a = n?.y ?? 0, o = n?.width ?? r.width, c = n?.height ?? r.height, l = document.createElement("div");
		l.className = "preview", this.#e.querySelector(".canvas").append(l);
		let u = i, d = a, f = o, p = c, m = () => Object.assign(l.style, {
			left: `${u}px`,
			top: `${d}px`,
			width: `${f}px`,
			height: `${p}px`
		});
		m(), this.#b(e, (r) => {
			let s = (r.clientX - e.clientX) / this.#a, l = (r.clientY - e.clientY) / this.#a;
			f = Math.max(8, o + (t.includes("w") ? -s : t.includes("e") ? s : 0)), p = Math.max(8, c + (t.includes("n") ? -l : t.includes("s") ? l : 0)), n && (u = t.includes("w") ? i + o - f : i, d = t.includes("n") ? a + c - p : a), m();
		}, (e) => {
			if (e) {
				this.#_();
				return;
			}
			if (n) {
				let e = {
					width: Math.round(f / M),
					height: Math.round(p / M)
				};
				u !== i && (e.xleft = Math.round(Number(n.properties.xleft) + (u - i) / M)), d !== a && (e.ytop = Math.round(Number(n.properties.ytop) + (d - a) / M)), this.#x(n, e);
			} else r.metadata ? this.#h(h(r.metadata, {
				windowwidth: String(Math.round(f / M)),
				windowheight: String(Math.round(p / M))
			})) : r.source && this.#h({
				uri: r.uri,
				version: r.version,
				edits: [...s(r.source, r.formId, "width", String(Math.round(f / M))).edits, ...s(r.source, r.formId, "height", String(Math.round(p / M))).edits]
			});
		});
	}
	#E(e, t) {
		if (this.#d) return;
		this.focus({ preventScroll: !0 });
		let n = this.#t;
		if (!n.source || !t.kind || !t.properties) return;
		let r = this.#e.querySelector(".canvas"), i = r.getBoundingClientRect(), a = (e.clientX - i.left) / this.#a, o = (e.clientY - i.top) / this.#a, s = document.createElement("div");
		s.className = "preview", r.append(s);
		let l = Number(t.properties.width) * M, u = Number(t.properties.height) * M, d = () => Object.assign(s.style, {
			left: `${a}px`,
			top: `${o}px`,
			width: `${l}px`,
			height: `${u}px`
		});
		d(), this.#b(e, (t) => {
			let n = (t.clientX - e.clientX) / this.#a, r = (t.clientY - e.clientY) / this.#a;
			n > 4 && (l = n), r > 4 && (u = r), d();
		}, (e) => {
			if (this.#i = "0", e) {
				this.#_();
				return;
			}
			try {
				let e = n.uri.startsWith("synthetic:"), r = e ? { ...t.properties } : {};
				t.kind === "segmentshape" && Object.assign(r, {
					point1x: String(N(a)),
					point1y: String(N(o)),
					point2x: String(N(a + Math.max(1, l - 2))),
					point2y: String(N(o + Math.max(1, u - 2)))
				}), this.#h(c(n.source, t.kind, e ? void 0 : t.style, {
					xleft: N(a),
					ytop: N(o),
					width: Math.round(l / M),
					height: Math.round(u / M)
				}, r, t.structured));
				let i = this.#t?.fields.at(-1);
				i && this.selectField(i.id);
			} catch (e) {
				this.#g(e), this.#_();
			}
		});
	}
};
customElements.get("gorak-frame-designer") || customElements.define("gorak-frame-designer", $);
//#endregion
export { $ as GorakFrameDesigner, M as WML_TO_CSS, u as applyIntent, g as applyMetadata, c as createField, f as deleteFields, ae as frameFromWml, k as imageKey, h as metadataEdit, p as nodeProperties, m as parseMetadata, a as parseWml, s as propertyEdit, o as resolveProperties, d as selectionRoots, n as structuredDefaults, l as structuredMarkup };
