export declare function nativeDefaults(kind: string): Readonly<Record<string, string>>;
