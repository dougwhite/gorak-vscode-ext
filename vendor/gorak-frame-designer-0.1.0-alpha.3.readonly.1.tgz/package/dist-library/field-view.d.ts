import type { FrameField } from "./designer.js";
import type { FieldBitmap } from "./bitmap.js";
export declare function applyBitmapBackground(element: HTMLElement, bitmap?: FieldBitmap, pattern?: string): void;
/** Render source data using DOM text only. Runtime scripts and HTML are never evaluated. */
export declare function renderField(element: HTMLElement, field: FrameField): void;
