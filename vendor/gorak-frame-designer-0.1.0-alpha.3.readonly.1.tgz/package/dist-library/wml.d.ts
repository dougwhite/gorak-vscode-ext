export interface Span {
    start: number;
    end: number;
}
export interface Attribute extends Span {
    value: string;
    valueSpan: Span;
    quote: string;
}
export interface WmlNode extends Span {
    id: string;
    kind: string;
    parentId?: string;
    openEnd: number;
    value?: string;
    contentSpan?: Span;
    insertAt: number;
    attributes: Record<string, Attribute>;
    children: WmlNode[];
}
export interface WmlDocument {
    uri: string;
    version: number;
    text: string;
    root: WmlNode;
    nodes: readonly WmlNode[];
}
export interface TextEdit extends Span {
    text: string;
    expected: string;
}
export interface EditIntent {
    uri: string;
    version: number;
    edits: readonly TextEdit[];
}
export type Defaults = Record<string, unknown>;
export interface DefaultsLayer {
    origin: string;
    defaults: Defaults;
}
export interface Property {
    value: string;
    origin: string;
}
/** Existing structured field properties come from WML only. */
export declare function structuredDefaults(_node: WmlNode, _layers: readonly DefaultsLayer[]): Record<string, unknown>;
export declare function parseWml(uri: string, version: number, text: string): WmlDocument;
export declare function resolveProperties(node: WmlNode, layers: readonly DefaultsLayer[]): Record<string, Property>;
export declare function propertyEdit(doc: WmlDocument, fieldId: string, key: string, value: string | null): EditIntent;
/** Creation inserts one new element; existing fields, scripts and unknown source stay untouched. */
export declare function createField(doc: WmlDocument, kind: string, style: number | undefined, geometry: Record<string, number>, defaults?: Readonly<Record<string, string>>, structured?: Readonly<Record<string, unknown>>): EditIntent;
/** Only supported structured palette properties are materialized for a new field. */
export declare function structuredMarkup(key: string, value: unknown, depth?: number): string;
export declare function applyIntent(doc: WmlDocument, intent: EditIntent): WmlDocument;
/** Selected ancestors already own their descendants; remove each subtree once. */
export declare function selectionRoots(doc: WmlDocument, ids: readonly string[]): WmlNode[];
export declare function deleteFields(doc: WmlDocument, ids: readonly string[]): EditIntent;
/** Scalar property elements (including invalid-XML-character PIs) remain source-addressable. */
export declare function nodeProperties(node: WmlNode): Record<string, string>;
