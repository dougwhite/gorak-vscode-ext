/** Data-only subset of native BitmapObject serialization. File handles are ignored. */
export interface FieldBitmap {
    width: number;
    height: number;
    rgba: Uint8ClampedArray;
}
export declare function decodeBitmap(encoded: string): FieldBitmap | undefined;
