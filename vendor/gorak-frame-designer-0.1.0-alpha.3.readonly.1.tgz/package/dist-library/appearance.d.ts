/** OpenROAD RGB values carry a tag above the Windows COLORREF (BGR) bytes. */
export declare function fieldColor(value: string | undefined): string | undefined;
export declare function applyAppearance(element: HTMLElement, properties: Readonly<Record<string, string>>): void;
