import { type DefaultsLayer, type WmlDocument } from "./wml.js";
export interface PaletteTool {
    id: string;
    label: string;
    icon: string;
    kind?: string;
    className?: string;
    style?: number;
    properties?: Record<string, string>;
    structured?: Record<string, unknown>;
}
export declare const nativeClass: (kind: string) => string;
export declare function paletteFor(source: WmlDocument, layers: readonly DefaultsLayer[]): PaletteTool[];
