export interface Cell {
    id: string;
    row: number;
    column: number;
    width: number;
    height: number;
    gravity?: number;
}
export interface CellLayout {
    positions: Map<string, {
        x: number;
        y: number;
    }>;
    width: number;
    height: number;
}
/** Native default matrix layout, calibrated using unequal EntryField/ButtonField cells. */
export declare function matrixLayout(cells: readonly Cell[], columns: number, rows: number, gravity?: number, margins?: {
    left: number;
    right: number;
    top: number;
    bottom: number;
}, bounds?: {
    width: number;
    height: number;
}): CellLayout;
export declare function outerPadding(kind: string): number;
