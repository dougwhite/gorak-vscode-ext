import { type DefaultsLayer, type WmlNode } from "./wml.js";
import { type FieldBitmap } from "./bitmap.js";
import { type FrameImages } from "./images.js";
export interface FieldChoice {
    label: string;
    value: string;
    bitmap?: FieldBitmap;
}
export declare function fieldColumns(node: WmlNode, layers: readonly DefaultsLayer[]): readonly {
    label: string;
    width: number;
}[];
export declare function fieldChoices(node: WmlNode, layers: readonly DefaultsLayer[], images?: FrameImages): readonly FieldChoice[];
