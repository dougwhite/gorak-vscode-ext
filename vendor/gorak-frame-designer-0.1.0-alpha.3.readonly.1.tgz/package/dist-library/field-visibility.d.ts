import type { FrameField } from "./designer.js";
export declare function pageVisible(field: FrameField, active: ReadonlyMap<string, number>): boolean;
/** Flat rendering retains source identities; clipping follows visual parent bounds. */
export declare function fieldClip(field: FrameField, fields: ReadonlyMap<string, FrameField>): string | undefined;
