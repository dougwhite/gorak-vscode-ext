export declare const schema: Record<string, Record<string, string>>;
export declare const windowNames: string[];
export declare function propertyName(key: string): string;
export declare function inspectorNames(kind: string, properties: Readonly<Record<string, string>>): string[];
export declare const windowKey: (label: string) => string;
export declare const propertyKey: (label: string) => string;
export declare const enums: Record<string, Record<string, string>>;
export declare function displayValue(kind: string, key: string, value: string): string;
export declare function validateProperty(kind: string, key: string, value: string): void;
