import { type DefaultsLayer, type WmlDocument } from "./wml.js";
import { type FrameMetadata } from "./metadata.js";
import type { PaletteTool } from "./palette.js";
import { type GroupKind } from "./grouping.js";
import type { FieldChoice } from "./choices.js";
import type { FieldBitmap } from "./bitmap.js";
export * from "./wml.js";
export * from "./metadata.js";
export { imageKey, type FrameImages } from "./images.js";
export { frameFromWml, WML_TO_CSS } from "./frame-model.js";
export interface FrameField {
    id: string;
    kind: string;
    name: string;
    x: number;
    y: number;
    width: number;
    height: number;
    label: string;
    properties: Readonly<Record<string, string>>;
    parentId?: string;
    propertyOrigins?: Readonly<Record<string, string>>;
    source?: {
        start: number;
        end: number;
    };
    choices?: readonly FieldChoice[];
    columns?: readonly {
        label: string;
        width: number;
    }[];
    pageScopes?: readonly {
        folderId: string;
        index: number;
    }[];
    tabTarget?: {
        folderId: string;
        index: number;
    };
    bitmap?: FieldBitmap;
    selectedBitmap?: FieldBitmap;
    backgroundBitmap?: FieldBitmap;
    prototype?: {
        kind: string;
        properties: Readonly<Record<string, string>>;
        choices?: readonly FieldChoice[];
    };
}
export interface FrameDocument {
    backgroundBitmap?: FieldBitmap;
    uri: string;
    version: number;
    title: string;
    width: number;
    height: number;
    fields: readonly FrameField[];
    source?: WmlDocument;
    metadata?: FrameMetadata;
    formId?: string;
    formProperties?: Readonly<Record<string, string>>;
    formOrigins?: Readonly<Record<string, string>>;
    palette?: readonly PaletteTool[];
    defaults?: readonly DefaultsLayer[];
}
export declare class GorakFrameDesigner extends HTMLElement {
    #private;
    /** Viewer mode; hosts opt in. Editing remains enabled by default. */
    get readOnly(): boolean;
    set readOnly(value: boolean);
    set document(value: FrameDocument);
    get document(): FrameDocument | undefined;
    get zoom(): number;
    get selectedFieldId(): string | undefined;
    get selectedFieldIds(): readonly string[];
    requestSourceNavigation(id?: string | undefined): void;
    selectFields(ids: readonly string[]): void;
    deleteSelection(): void;
    groupSelection(kind: GroupKind, orientation?: number): void;
    ungroupSelection(): void;
    selectField(id: string): void;
    selectFrame(): void;
    connectedCallback(): void;
}
