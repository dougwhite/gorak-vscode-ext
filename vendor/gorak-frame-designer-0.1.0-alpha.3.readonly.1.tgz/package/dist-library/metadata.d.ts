import type { Attribute, EditIntent } from "./wml.js";
/** Only scalar frame metadata is interpreted; scripts and other TOML sections remain opaque. */
export interface FrameMetadata {
    uri: string;
    version: number;
    text: string;
    attributes: Record<string, Attribute>;
    insertAt: number;
}
export declare function parseMetadata(uri: string, version: number, text: string): FrameMetadata;
export declare function metadataEdit(doc: FrameMetadata, values: Record<string, string | null>): EditIntent;
export declare function applyMetadata(doc: FrameMetadata, intent: EditIntent): FrameMetadata;
